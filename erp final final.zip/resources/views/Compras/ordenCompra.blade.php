@extends('Compras.Index')


@section('content')
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Orden de Compra Proveedor </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="{{route('salirPedido')}}" method="POST">
  @csrf
  <div class="form-group">
      <label class="control-label">Numero de Pedido :</label> <select name="idped" id="idped" >
      <option value="">Selecciona el Nro</option>
      @foreach($pedido as $opcion):
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->id;?></option>
      @endforeach
      </select>
     <label class="control-label"style="position:absolute;left: 55%;">Fecha :  <?php echo $fecha;?></label>
    </div>
    <table class="table table-striped" id="table-pedido">
        <thead>
        <tr>
        <th></th>
           <th>Producto</th>
           <th>Cantidad</th>
            <th>Precio</th>
            <th>Total</th>
            <th>Fecha expiracion</th>
            <th>Cantidad Actual</th>
        </tr>
        </thead>
        <tbody id="tdprod" values="">
         
         
        </tbody>
    </table><br><br>


    <div  class="form-group" style="position:absolute;left: 55%;">
    <label class="control-label">TOTAL A PAGAR :  </label><input style="position:absolute;left: 150%;" name="sumatotal" id="sumatotal" type="text" value="0" readonly="readonly" >
    </div><br><br>
    <button type="button" id="Bguardar" class="btn btn-primary">Guardar</button>
    <button type="button" id="Benviar" class="btn btn-defaul">Enviar</button>
    <button type="submit" id="Bsalir" class="btn btn-danger">Salir</button>
    <input type="hidden" id="valorj" name="valorj" value="0"/>
     <input type="hidden" id="canttotal" name="canttotal" value="0"/>
     <input type="hidden" id="idpedido" name="idpedido" value="0"/>

  
 </div>
 </form>
 <script src="/js/compras/ordenCompra.js">
 </script>
 </div>
@endsection
