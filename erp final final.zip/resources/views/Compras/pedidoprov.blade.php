@extends('Compras.Index')


@section('content')
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Orden de Pedido Proveedor </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="{{route('salirPedido')}}" method="POST">
  @csrf
  <div class="form-group">
      <label class="control-label">Proveedor:</label> <select name="iddprov" id="iddprov" >
      <option value="">Selecciona el Proveedor</option>
      @foreach($proveedor as $opcion):
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->nombre;?></option>
      @endforeach
      </select>
     <label class="control-label"style="position:absolute;left: 55%;">Fecha :  <?php echo $fecha;?></label>
    </div>
    <label >Producto:</label><select name="idprod" id="idprod"> 
                          <option value="">Agregar Producto</option>
                      @foreach($producto as $opcionP):
                       <option value="<?php echo $opcionP->id;?>"><?php echo $opcionP->nombre;?></option>
                    @endforeach
                   </select>
    <table class="table table-striped" id="table-predido">
        <thead>
        <tr>
        <th></th>
           <th>Producto</th>
           <th>Cantidad</th>
            <th>Precio</th>
            <th>Total</th>
            <th>Fecha expiracion</th>
            <th>Cantidad Actual</th>
        </tr>
        </thead>
        <tbody id="tdprod">
         
         
        </tbody>
    </table><br><br>
    <div  class="form-group" style="position:absolute;left: 55%;">
    <label class="control-label">TOTAL A PAGAR :  </label><input style="position:absolute;left: 150%;" name="sumatotal" id="sumatotal" type="text" value="0" readonly="readonly" >
    </div><br><br>
    <button type="button" id="Bguardar" class="btn btn-primary">Guardar</button>
    <button type="button" id="Benviar" class="btn btn-defaul">Enviar</button>
    <button type="submit" id="Bsalir" class="btn btn-danger">Salir</button>
    <input type="hidden" id="valorj" name="valorj" value="0"/>
     <input type="hidden" id="canttotal" name="canttotal" value="0"/>
     <input type="hidden" id="idpedido" name="idpedido" value="0"/>
  </form>
</div>
<script src="/js/compras/compras.js">
</script>
@endsection


