@extends('Compras.Index')


@section('content')



<div class="container">
  <h2>Crear Nuevo Proovedor </h2><br>
  <form action="{{route('crearproveedor')}}" method="POST">
  @csrf
    <div class="form-group">
      <label >Nombre del Prooveedor:</label>
      <input type="text" class="form-control" placeholder="Nombre de la Empresa" name="nombre">
    </div>
    <div class="form-group">
      <label >NIT:</label>
      <input type="text" class="form-control" placeholder="" name="nit">
    </div>
    <div class="form-group">
      <label >Tipo:</label>
      <input type="text" class="form-control" placeholder="" name="tipo">
    </div>
    <div class="form-group">
      <label >Direccion:</label>
      <input type="text" class="form-control" placeholder="" name="direccion">
    </div>
    <div class="form-group">
      <label >E-Mail:</label>
      <input type="text" class="form-control" placeholder="" name="email">
    </div>
    <div class="form-group">
      <label >Telefono:</label>
      <input type="text" class="form-control" placeholder="" name="telefono">
    </div>
    <div class="form-group">
      <label >Estado:</label>
      <select name="estado" >
        <option value="">Selecciona el estado</option>
            <option value="1">Activo</option>
            <option value="2">Pasivo</option>
      </select>
    </div>
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>




@endsection