@extends('Compras.Index')

@section('content')

<div class="container">
  <h2>prueba </h2><br>
  <form action="{{route('seleccionproveedor')}}" method="POST">
  @csrf
  <div class="form-group">
      <label >Proveedor:</label>
    </div>
    <button type="submit" class="btn btn-default">buscar</button>
  </form>
</div>
<?php 
echo $id;
echo $estado;
echo $ids;
?>

@endsection