@extends('Compras.Index')


@section('content')



<div class="container">
  <h2>Modificar datos de Proovedor </h2><br>
  <form action="{{route('guardarproveedor')}}" method="POST">
  @csrf
  @foreach($proveedor as $opcion):
    <h3>Datos de Proveedor : </h3><br>
    <label>ID Porveedor: <?php echo $id;?></label><br>
    <div class="form-group">
      <label >Nombre del Prooveedor:</label>
      <input type="hidden" class="form-control" name="id" value="<?php echo $opcion->id;?>">
      <input type="text" class="form-control" placeholder="" name="nombre" value="<?php echo $opcion->nombre;?>">
    </div>
    <div class="form-group">
      <label >NIT:</label>
      <input type="text" class="form-control" placeholder="" name="nit"  value="<?php echo $opcion->nit;?>">
    </div>
    <div class="form-group">
      <label >Tipo:</label>
      <input type="text" class="form-control" placeholder="" name="tipo"  value="<?php echo $opcion->tipo;?>">
    </div>
    <div class="form-group">
      <label >Direccion:</label>
      <input type="text" class="form-control" placeholder="" name="direccion"  value="<?php echo $opcion->direccion;?>">
    </div>
    <h3>Comunicacion : </h3><br>
    <div class="form-group">
      <label >E-Mail:</label>
      <input type="email" class="form-control" placeholder="" name="email"  value="<?php echo $opcion->email;?>">
    </div>
    <div class="form-group">
      <label >Telefono:</label>
      <input type="text" class="form-control" placeholder="" name="telefono"  value="<?php echo $opcion->telefono;?>">
    </div>
    <div class="form-group">
    <label >Estado Actual: <?php
    if ($opcion->estado == 1){
      echo "Activo";
      }else{ echo "Pasivo";}
    // echo $opcion->estado;
    ?></label><br>
      <label >Estado:</label>
      <select name="estado" >
        <option value="">Selecciona el estado</option>
            <option value="1">Activo</option>
            <option value="2">Pasivo</option>
      </select>
    </div>
    <button type="submit" class="btn btn-default">Guardar</button>
    <a href="{{route('eliminarproveedor')}}" method="POST"><button type="submit" class="btn btn-default" style="position:absolute;left: 35%;">Eliminar</button></a>
    @endforeach
  </form>
</div>

@endsection