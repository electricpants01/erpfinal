@extends('Compras.Index')


@section('content')
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Orden Pedido Proveedor </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="{{route('nuevoPedido')}}" method="POST">
  @csrf
 <div id="divform" name="divform">
  <div class="form-group">
      <label class="control-label">Cambiar estado de Pedido: </label> <select name="idpedestado" id="idpedestado" >
      <option value="">Selecciona el Nro</option>
      @foreach($pedido as $opcion):
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->id;?></option>
      @endforeach
      </select>
  </div>
       <br><br>
      <button type="submit" id="Bguarda" class="btn btn-primary">Nuevo Pedido</button>
      <button type="hidden" id="Benviar" class="btn btn-danger">Salir</button>
      <button type="button" id="Bvolver" class="btn btn-danger">Salir</button>
      <input type="hidden" id="valorj" name="valorj" value="0"/>
      <input type="hidden" id="canttotal" name="canttotal" value="0"/>
      <input type="hidden" id="idcompra" name="idcompra" value="0"/>
 </div>
 </form>
  <script src="/js/compras/OrdenCompra.js">
 </script>
 </div>
@endsection