@extends('Compras.Index')


@section('content')



<div class="container">
  <h2>Modificar datos de Proovedor </h2><br>
  <form action="{{route('seleccionproveedor')}}" method="POST">
  @csrf
  <div class="form-group">
      <label >Proveedor:</label> <select name="idprov" >
      <option value="">Selecciona el Proveedor</option>
      @foreach($proveedor as $opcion):
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->nombre;?></option>
      @endforeach
      </select>
    </div>
    <button type="submit" class="btn btn-default">buscar</button>
  </form>
</div>
@endsection