@extends('Compras.Index')


@section('content')
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Actualizar Estado de Devolucion </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="{{route('salirPedido')}}" method="POST">
  @csrf
  <div  id="cabeza" class="form-group">
      <label class="control-label">Numero de devolucion:</label> <select name="iddevolucion" id="iddevolucion" >
      <option value="">Selecciona el Nro</option>
      @foreach($devolucion as $opcion):
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->id;?></option>
      @endforeach
      </select>
     <label class="control-label"style="position:absolute;left: 55%;">Fecha :  <?php echo $fecha;?></label><br><br>
    </div>
      <table class="table table-striped" id="table-pedido">
        <thead>
        <tr>
        <th></th>
           <th>Producto</th>
           <th>Cantidad</th>
            <th>Precio</th>
            <th>Total</th>
            <th>Fecha expiracion</th>
            <th>Cantidad Actual</th>
        </tr>
        </thead>
        <tbody id="tdprod" values="">
         
         
        </tbody>
      </table><br><br>
 
        <div  class="form-group" style="position:absolute;left: 55%;">
          <label class="control-label">TOTAL :  </label><input style="position:absolute;left: 150%;" name="sumatotal" id="sumatotal" type="text" value="0" readonly="readonly" >
        </div><br><br>
     <div id="contestado" name="contestado">
     
     </div>
      <div id="selector">

      </div><br><br>
      <button type="button" id="Bguardar" class="btn btn-primary">Guardar</button>
      <button type="submit" id="Bsalir" class="btn btn-danger">Salir</button>
      <input type="hidden" id="valorj" name="valorj" value="0"/>
      <input type="hidden" id="canttotal" name="canttotal" value="0"/>
      <input type="hidden" id="iddev" name="iddev" value="0"/>
   </div>
  </form>
  <script src="/js/compras/estadoDevolucion.js">
 </script>
 </div>
@endsection