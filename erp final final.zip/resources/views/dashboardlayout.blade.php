<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{{asset('css/dashboard/bootstrap.min.css')}}">
  <script src="{{asset('css/dashboard/jquery.js')}}"></script>
  <script src="{{asset('css/dashboard/bootstrap.js')}}"></script>

</head>
<body>

@yield('content')

</body>
</html>
