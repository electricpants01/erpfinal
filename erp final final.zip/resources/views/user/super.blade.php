@extends('user.superlayout')

@section('content')
<div class="row content">
    <div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>Empieza a beber!</h1>
      <table class="table table-striped">
    <tbody>
    @foreach($products as $product)
            <tr>
                <td>
                    <h2>{{$product->nombre}}</h2> <br>
                    {{$product->descripcion}} <br>
                    <img src="{{asset($product->imagen)}}" class="img-thumbnail" alt="{{$product->nombre}}" width="304" height="236"> <br>
                    Precio :  {{ $product->costo_actual}}$
                    <a href="{{route('adicionarcarrito',[$product->almacen_id,$product->producto_id])}}" class="btn btn-success" role="button">Añadir al Carrito</a>
                </td>
            </tr>    
        @endforeach 
    </tbody>
  </table>
    {{$products->links()}}
    </div>
    <div class="col-sm-2 sidenav">
    </div>
  </div>

@endsection