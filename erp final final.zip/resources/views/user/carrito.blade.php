
@extends('user.superlayout')

@section('content')
<div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
<h1>Tu carrito del Super </h1>
      <table class="table table-striped">
    <tbody>
    <tr>
        <th>Nombre del Producto</th>
        <th>Precio</th>
        <th>Cantidad</th>
    </tr>
    @foreach($products as $product)
            <tr>
                <td>{{$product->nombre}}</td>
                <td>{{$product->costo_actual}}</td>
                <td>{{$product->cantidad}}</td>
            </tr>    
        @endforeach 
    </tbody>
  </table>
  <h1>La suma del carrito es : {{$suma->suma}}</h1>
  <h1>Envio Gratuito + IVA(13%) : {{$pagar}}</h1>

  <!-- aqui va el metodo de pago -->
  <h2>Pago por PayPal </h2>
  <br>

  <div id="paypal-button-container"></div>
  
  <script
    src="https://www.paypal.com/sdk/js?client-id=AWrPZLukAz6W304d-dOPXvx7Gp93-iOl3T8uRIPa_k7ZgC6BXZxSJkCN2K1Qs7fB6vxfPnOXmEJ9TlmA">
  </script>

  <script>
  paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: '{{$pagar}}'
          }
        }]
      });
    },
    onApprove: function(data, actions) {
      // Capture the funds from the transaction
      window.location="{{route('compracarrito')}}";
      return actions.order.capture().then(function(details) {
        // Show a success message to your buyer
        console.log('transaccion exitosa');
      });
    }
  }).render('#paypal-button-container');
</script>
</body>
  <!--hasta aqui -->
  <div class="col-sm-2 sidenav">
    </div>
@endsection