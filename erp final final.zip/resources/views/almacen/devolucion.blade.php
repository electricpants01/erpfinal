@extends('almacen.index')


@section('content')



<table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha expiracion</th>
            <th>Dias antes de expiracion</th>
            <th>Cantidad</th>
        </tr>
        </thead>
        <tbody>
        @foreach($productos as $producto)
                <tr>
                    <td>{{$producto->id}}</td>
                    <td>{{$producto->nombre}}</td>
                    <td>{{$producto->costo_actual}}</td>
                    <td>{{$producto->fecha_expiracion}}</td>
                    <td>{{$producto->dias}}</td>
                    <td>{{$producto->cant_pedido}}</td>
                </tr>    
            @endforeach 
        </tbody>
    </table>



@endsection