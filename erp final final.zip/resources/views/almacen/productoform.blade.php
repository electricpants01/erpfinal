@extends('almacen.index')


@section('content')



<div class="container">
  <h2>Crear Nuevo Producto </h2><br>
  <form action="{{route('crearproducto')}}" method="POST">
  @csrf
    <div class="form-group">
      <label >Nombre del Producto:</label>
      <input type="text" class="form-control" placeholder="La direccion del almacen" name="nombre">
    </div>
    <div class="form-group">
      <label >Costo:</label>
      <input type="text" class="form-control" placeholder="Costo del producto en dolares" name="costo">
    </div>
    <div class="form-group">
      <label >Cantidad:</label>
      <input type="text" class="form-control" placeholder="Cantidad del producto" name="cantidad">
    </div>
    <div class="form-group">
      <label >Iventario minimo:</label>
      <input type="text" class="form-control" placeholder="Cantidad del producto" name="inventario_min">
    </div>
    <div class="form-group">
      <label >Fecha de expiracion:</label>
      <input type="date"  name="fecha">
    </div>
    <div class="form-group">
      <label >Descripcion:</label>
      <input type="text" class="form-control" placeholder="Una breve descripcion del producto" name="descripcion">
    </div>

    <div class="form-group">
      <label >Categoria:</label>
      <select name="categoria" >
        <option value="">Selecciona la categoria</option>
        @foreach( $categorias as $categoria)
            <option value="{{$categoria->id}}">{{$categoria->nombre}}</option>
        @endforeach
      </select>
    </div>

    <div class="form-group">
      <label >Marca:</label>
      <select name="marca" >
        <option value="">Selecciona la marca</option>
        @foreach( $marcas as $marca)
            <option value="{{$marca->id}}">{{$marca->nombre}}</option>
        @endforeach
      </select>
    </div>
  
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>




@endsection