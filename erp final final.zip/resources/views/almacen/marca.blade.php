@extends('almacen.index')


@section('content')

<div class="container">
  <h2>Crear Marca o Categoria</h2><br>
  <form action="{{route('marca')}}" method="POST">
  @csrf
  <div class="form-group">
  <label for="text">Primero seleccione a que tabla quiere insertar:</label><br>
      <select name="tabla">
        <option value="">INSERTAR A:</option>
        <option value="1">Marca</option>
        <option value="2">Categoria</option>
      </select>
    </div>
    <div class="form-group">
      <label for="text">Nombre:</label>
      <input type="text" class="form-control"  placeholder="Introduzca el nombre" name="nombre">
    </div>
    
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>
@endsection