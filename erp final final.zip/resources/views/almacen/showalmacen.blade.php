@extends('almacen.index')


@section('content')

    <table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Direccion</th>
            <th>Telefono</th>
            <th>Valor Almacenado</th>
            <th>Cantidad Producto</th>
        </tr>
        </thead>
        <tbody>
        @foreach($almacenes as $almacen)
                <tr>
                    <td>{{$almacen->id}}</td>
                    <td>{{$almacen->direccion}}</td>
                    <td>{{$almacen->telefono}}</td>
                    <td>{{$almacen->valor_almacenado}}</td>
                    <td>{{$almacen->cantidad}}</td>
                </tr>    
            @endforeach 
        </tbody>
    </table>
@endsection