<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{{asset('css/dashboard/bootstrap.min.css')}}">
  <script src="{{asset('css/dashboard/jquery.js')}}"></script>
  <script src="{{asset('css/dashboard/bootstrap.js')}}"></script>

</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Super ERP </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="{{route('dashboard')}}">Inicio</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Producto <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="{{route('mostrarprod')}}">Ver Producto</a></li>
          <li><a href="{{route('productoform')}}">Crear Producto</a></li>
          <li><a href="{{route('marca')}}">Crear Marca o Categoria</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Almacen <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="{{route('mostraralmacen')}}">Ver Almacenes</a></li>
          <li><a href="{{route('almacenform')}}">Crear Nuevo Almacen</a></li>
        </ul>
      </li>
      <li><a href="{{route('devolucion1')}}">Devolucion</a></li>
      <li><a href="{{route('abastecimiento')}}">Abastecimiento</a></li>
    </ul>
  </div>
</nav>

<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">

    </div>
    <div class="col-sm-8 text-left"> 



        @yield('content')



    </div>
    <div class="col-sm-2 sidenav">
    </div>
  </div>
</div>


</body>
</html>
