@extends('almacen.index')

@section('content')

    <table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha pedido</th>
            <th>Cantidad</th>
        </tr>
        </thead>
        <tbody>
        @foreach($productos as $producto)
                <tr>
                    <td>{{$producto->id}}</td>
                    <td>{{$producto->nombre}}</td>
                    <td>{{$producto->costo_actual}}</td>
                    <td>{{$producto->fecha_ultimo_pedido}}</td>
                    <td>{{$producto->cant_pedido}}</td>
                </tr>    
            @endforeach 
        </tbody>
    </table>
    <h1>Cantidad de productos : {{$cant->cant}}</h1>
    <h1>Actvo de la Empresa  : {{$activo->activo}}</h1>
@endsection