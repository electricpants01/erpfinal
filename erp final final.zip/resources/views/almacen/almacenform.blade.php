@extends('almacen.index')


@section('content')


<div class="container">
  <h2>Crear Nuevo Almacen</h2><br>
  <form action="{{route('crearalmacen')}}" method="POST">
  @csrf
    <div class="form-group">
      <label >Direccion:</label>
      <input type="text" class="form-control" placeholder="La direccion del almacen" name="direccion">
    </div>
    <div class="form-group">
      <label >Telefono:</label>
      <input type="text" class="form-control" placeholder="Telefono de referencia" name="telefono">
    </div>
  
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>

@endsection