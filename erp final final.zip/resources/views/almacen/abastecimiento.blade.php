@extends('almacen.index')


@section('content')



<table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha expiracion</th>
            <th>Cantidad Actual</th>
            <th>Inventario minimo</th>
        </tr>
        </thead>
        <tbody>
        @foreach($productos as $producto)
                <tr>
                    <td>{{$producto->id}}</td>
                    <td>{{$producto->nombre}}</td>
                    <td>{{$producto->costo_actual}}</td>
                    <td>{{$producto->fecha_expiracion}}</td>
                    <td>{{$producto->cant_pedido}}</td>
                    <td>{{$producto->inventario_min}}</td>
                </tr>    
            @endforeach 
        </tbody>
    </table>



@endsection