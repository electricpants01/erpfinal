<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('css/dashboard/bootstrap.min.css')}}">
  <script src="{{asset('css/dashboard/jquery.js')}}"></script>
  <script src="{{asset('css/dashboard/bootstrap.js')}}"></script>
    <title>Factura</title>
</head>
<body>

<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">

    </div>
    <div class="col-sm-8 text-left"> 

<img src="{{asset('erp.png')}}" height="100" width="100">
<strong><h1 >Reporte Dinamico</h1></strong>


<table class="table table-striped">
        <thead>
        <tr>
            <?php   
            if( $facturacols != NULL){
                foreach($facturacols as $facturacol){
                    echo "<th>".$facturacol."</th>";
                }
            }
            if( $ventacols != NULL){
                foreach($ventacols as $venta){
                    echo "<th>".$venta."</th>";
                }
            }
            if($detallecols != NULL){
                foreach($detallecols as $detalle){
                    echo "<th>".$detalle."</th>";
                }
            }
            ?>
        </tr>
        </thead>
        <tbody>
        <?php
            foreach($valores as $valor){
                echo "<tr>";
                    if( $facturacols != NULL){
                        foreach($facturacols as $facturacol){
                            echo "<td>".$valor->$facturacol."</td>";
                        }
                    }
                    if( $ventacols != NULL){
                        foreach($ventacols as $venta){
                            echo "<td>".$valor->$venta."</td>";
                        }
                    }
                    if ($detallecols != NULL){
                        foreach($detallecols as $detalle){
                            echo "<td>".$valor->$detalle."</td>";
                        }
                    }
                echo "</tr>";
            }
        ?>
        </tbody>
    </table>

    
    </div>
    <div class="col-sm-2 sidenav">
    </div>
  </div>
</div>

   
</body>
</html>