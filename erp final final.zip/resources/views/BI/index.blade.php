<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="{{asset('css/dashboard/bootstrap.min.css')}}">
  <script src="{{asset('css/dashboard/jquery.js')}}"></script>
  <script src="{{asset('css/dashboard/bootstrap.js')}}"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
  <style>
  #draggable { width: 100px; height: 100px; padding: 0.5em; float: left; margin: 10px 10px 10px 0; }
  #droppable { width: 150px; height: 150px; padding: 0.5em; float: left; margin: 10px; }
  .tamaño {width: 100px; height: 100px; padding: 0.5em; float: left; margin: 10px;}
  </style>
<style>
#menubi * { list-style:none;}
#menubi li{ line-height:180%;}
#menubi li a{color:#222; text-decoration:none;}
#menubi li a:before{ content:"\025b8"; color:#ddd; margin-right:4px;}
#menubi input[name="list"] {
	position: absolute;
	left: -1000em;
	}
#menubi label:before{ content:"\025b8"; margin-right:4px;}
#menubi input:checked ~ label:before{ content:"\025be";}
#menubi .interior{display: none;}
#menubi input:checked ~ ul{display:block;}

</style>
</head>
<body style="background-color:#BDBDBD;">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Super ERP </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="{{route('dashboard')}}">Inicio</a></li>
      <li><a class="dropdown-toggle" data-toggle="dropdown" href="#">Reportes</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Graficos </a></li>

      <li><a class="dropdown-toggle" data-toggle="dropdown" href="{{route('restBI')}}">Restablecer</a></li>

    </ul>
  </div>
</nav>

<div class="container-fluid text-center">
  <div class="row content">
      <div class="col-sm-2 sidenav"> </div>
    <div class="col-sm-8 text-left">

            @yield('content')
       <div class="container-fluid">
         <div class="row">
          <h2>Reportes Dinamicos</h2><br><br>
           <label class="control-label">Seleccione Area:</label> <select name="idcubo" id="idcubo" >
             <option value="">Seleccione opcion</option>
             <option value="1">Compras</option>
               <option value="2">Ventas</option>
                  <option value="3">Almacen</option></select><br><br>
                 <div class="col-md-12">
                    <div class="row">
                          <div class="col-md-8">
                           <table class="table table-striped" id="table-pedido">
                           <thead>
                                 <tr><th></th>
                                 <th>Producto</th>
                                  <th>Cantidad</th>
                                 <th>Precio</th>
                                 <th>Total</th>
                                  <th>Fecha expiracion</th>
                                  <th>Cantidad Actual</th></tr>
                            </thead>
                            <tbody id="tdprod" values="">
                           </tbody>
                          </table><br><br>
                         </div>
                          <div class="col-md-1"></div>
                      <div id= "opcion"class="col-md-3">
                        <label for="as">Opciones</label>

                        <ul id="menubi">
                           <li><input type="checkbox" name="list" id="nivel1-1"><label for="nivel1-1">Nivel 1</label>
                              <ul class="interior">
                               <li id="n1" name="Cnombre"><a href="#r">Nivel 2</a></li>
                              </ul>
                        </li>
                          <li><input type="checkbox" name="list" id="nivel2-1"><label for="nivel1-1">Nivel 2</li>
                         </ul>
                     </div>
                    </div>
                    <div class="row">
                      <div class="col-md-8">
                        <label for="as"></label><br><br><br><br><br><br>
                      </div>
                      
                      <div  class="col-md-2">
                      <label for="as">Filas</label>
                       <div name="filas" id="filas" class="ui-widget-header tamaño"></div>
                      </div>
                      <div id="columnas" class="col-md-2">
                         <label for="as">Columnas</label>
                         <div id="columnas" name="columnas" class="ui-widget-header tamaño"></div>
                      </div>

                    </div>
                    <div class="row">
                       <div class="col-md-8">
                         <label for="as"></label>
                       </div>
                       <div class="col-md-2">
                         <label for="as">Busqueda</label>
                         <div id="busqueda" name="busqueda" class="ui-widget-header tamaño"></div>
                       </div>
                       <div class="col-md-2">
                          <label for="as">Filtro</label>
                          <div id="filtro" name="filtro" class="ui-widget-header tamaño"></div>
                       </div>

                      </div>
                    </div>
                 </div>

           
</head>
<body>
 
<div id="draggable" name="nombre" class="ui-widget-content">
  <p>Drag me to my target</p>
</div>
 
<div id="droppable" class="ui-widget-header">
  <p>Drop here</p>
</div>


         </div>
       </div>
    </div>
  </div>
</div>
<script src="/js/BI/BI.js">
 </script>
</body>
</html>
