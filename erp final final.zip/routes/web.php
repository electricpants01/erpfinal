<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('user.login');
})->middleware('guest');

// user login + carrito
Route::get('super/color/{color}','LoginUserController@color')->name('color');
Route::get('/super/letra/{letra}','LoginUserController@letra')->name('letra');
Route::get('/login','LoginUserController@login')->name('login');
Route::post('/login','LoginUserController@entrar')->name('login');
Route::get('/super','LoginUserController@super')->name('super')->middleware('auth');
Route::post('/logout','LoginUserController@logout')->name('logout');
Route::get('/register','LoginUserController@showRegister')->name('register');
Route::post('/register','LoginUserController@register')->name('register');
Route::get('/adicionar/{almacen_id}/{producto_id}','LoginUserController@adicionarCarrito')->name('adicionarcarrito');
Route::get('/carrito','LoginUserController@carrito')->name('carrito')->middleware('auth');
Route::get('/compracarrito','LoginUserController@compraCarrito')->name('compracarrito');
Route::get('/factura/{user}/{venta}','LoginUserController@factura')->name('factura');

//admin login
//Auth::routes();
Route::get('/admin/login',function(){
  return view('auth.login');
})->name('adminlogin');
Route::post('/admin/login','Auth\LoginController@login')->name('adminlogin');
Route::post('/admin/logout','Auth\LoginController@logout')->name('adminlogout');
Route::get('/dashboard','Auth\DashboardController@index')->name('dashboard')->middleware('auth');

//Almacenes
Route::get('/dashboard/almacen','AlmacenController@index')->name('indexalmacen');
Route::get('/dashboard/almacen/producto','AlmacenController@showProducto')->name('mostrarprod');
Route::get('/dashboard/almacen/prodform','AlmacenController@productoForm')->name('productoform');  // formulario producto nuevo
Route::post('/dashboard/almacen/prodform','AlmacenController@crearProducto')->name('crearproducto'); // crear producto
Route::get('/dashboard/almacen/almacen','AlmacenController@showAlmacen')->name('mostraralmacen');
Route::get('/dashboard/almacen/ialmacen','AlmacenController@almacenForm')->name('almacenform');
Route::post('/dashboard/almacen/ialmacen','AlmacenController@crearAlmacen')->name('crearalmacen'); // crear almacen
Route::get('/dashboard/almacen/marca','AlmacenController@marcaForm')->name('marca');    // crear marca o categoria
Route::post('/dashboard/almacen/marca','AlmacenController@crearMarca')->name('marca');   // insert de marca o categoria
Route::get('/dashboard/almacen/devolucion','AlmacenController@verDevolucion')->name('devolucion1');
Route::get('/dashboard/almacen/abastecimiento','AlmacenController@verAbastecimiento')->name('abastecimiento'); // los productos q necesitan reabastecerse

//Ventas
Route::get('/dashboard/ventas','VentasController@index')->name('ventasindex');
Route::get('/dashboard/reporteventas','VentasController@reporte')->name('ventasreporte');
Route::post('/dashboard/reporteventas','VentasController@creareporte')->name('creareporte');
Route::get('/dashboard/reporteventashtml','VentasController@reportehtml')->name('ventasreportehtml');
Route::post('/dashboard/reporteventashtml','VentasController@creareportehtml')->name('creareportehtml');


//compras
Route::get('/dashboard/Compras','comprasController@index')->name('indexCompras');
Route::get('/dashboard/Compras/AddProveedor','comprasController@AddProveedor')->name('addProveedor');//formulario new proveedor
Route::post('/dashboard/Compras/AddProveedor','comprasController@AddProveedors')->name('crearproveedor');//crear proveedor
Route::get('/dashboard/Compras/Proveedor','comprasController@ModificarProveedor')->name('modproveedor');//form seleccionar proveedor
Route::post('/dashboard/Compras/datosProveedor','comprasController@SeleccionarProveedor')->name('seleccionproveedor');// proveedor seleccionado
Route::post('/dashboard/Compras/guardar','comprasController@GuardarProveedors')->name('guardarproveedor');
Route::post('/dashboard/Compras/eliminar','comprasController@EliminarProveedors')->name('eliminarproveedor');
  //pedidos
Route::get('/dashboard/Compras/ePedidoProv','comprasController@EstadoPedidoProv')->name('ePedidoProveedor');//formulario para pedido de producto
  Route::post('/dashboard/Compras/ePedidoProv/nuevo','comprasController@nuevoPedido')->name('nuevoPedido');//agregar nuevo pedido
  Route::post('/dashboard/Compras/ePedidoProv/cambiarEstado','comprasController@estadoPedido');//agregar nuevo pedido
 
  Route::get('/dashboard/Compras/PedidoProv','comprasController@PedidoProv')->name('PedidoProveedor');//formulario para pedido de producto
  Route::get('/dashboard/Compras/PedidoSuc','comprasController@PedidoSuc')->name('PedidoSucursal');//formulario para pedido de sucursal
  Route::post('/dashboard/Compras/PedidoProv/agregar','comprasController@AgregarPedidoProv');//agregar nuevo pedido
  Route::post('/dashboard/Compras','comprasController@index');
  Route::post('/dashboard/Compras/PedidoProv/salir','comprasController@redirectindex')->name('salirPedido');//agregar nuevo pedido
  //orden de compra
  Route::get('/dashboard/Compras/CompraProv','comprasController@CompraProv')->name('CompraProveedor');//formulario para pedido de producto
  Route::post('/dashboard/Compras/CompraProv/agregar','comprasController@AgregarCompraProv');//agregar nuevo pedido
  Route::post('/dashboard/Compras/CompraProv/salir','comprasController@redirectindex')->name('salirCompra');//agregar nuevo pedido
  //ingreso de productos
  Route::get('/dashboard/IngresoProd/IngresoProv','comprasController@IngresoProdProv')->name('IngresoProveedor');//formulario para pedido de producto
  Route::post('/dashboard/Compras/IngresoProv/agregar','comprasController@AgregarIngresoProdProv');//agregar nueva compra de productos
  //devolucion
  Route::get('/dashboard/Compras/Devolucion','comprasController@AddDevolucion')->name('devolucion');//formulario new proveedor
  Route::post('/dashboard/Compras/Devolucion/agregar','comprasController@AgregarDevolucion');//agregar nueva compra de productos
  
  Route::get('/dashboard/Compras/estadoDevolucion','comprasController@EstadoDevolucion')->name('estadodevolucion');//formulario new proveedor
  Route::post('/dashboard/Compras/estadoDevolucion/agregar','comprasController@AgregarEstadoDevolucion');//agregar nueva compra de productos
  
  /// Inteligencia de negocios
  Route::get('/dashboard/BI','BIController@index')->name('indexaBI');
  Route::get('/dashboard/BI/rest','BIController@rest')->name('restBI');
    

  ///reportes pdf
  Route::get('pdf', function(){
    $pdf = PDF::loadView('reportes/vista');
    return $pdf->stream('arhc.pdf');
  });

  //correro
  Route::post('/dashboard/Compras/PedidoProv/mail','emailcontroller@store');
  Route::post('/dashboard/Compras/CompraProv/mail','emailcontroller@storeCompra');
  Route::post('/dashboard/Compras/Devolucion/mail','emailcontroller@storeDevolucion');
  