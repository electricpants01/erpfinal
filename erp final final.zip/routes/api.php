<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/Compras/pedidoProv/{id}','comprasController@showproduct');
Route::get('/Compras/pedidoProv/enviar/{id}','comprasController@enviardatospedido');
Route::get('/Compras/pedidoProv/enviar','comprasController@ultimopedido');
Route::get('/Compras/compraProv/{id}','comprasController@showdetallepedido');
Route::get('/Compras/IngresoProv/{id}','comprasController@showdetallecompra');
Route::get('/Compras/detalleProv/{id}','comprasController@showdetalleproveedor');
Route::get('/Compras/devolucion/{id}','comprasController@showdetalledevolucion');