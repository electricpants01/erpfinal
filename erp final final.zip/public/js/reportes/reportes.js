
$(function(){
//$('#idprod').on('change', selectprod);
 
/* $("body").on("click",".btn-danger", elminarfila);
 $("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Bguardar').on('click', guardarDatos);
 $('#Benviar').on('click', enviarid);*/
 cargarFormulario();
 $(document).ready(enviarid);
});

function cargarFormulario(){

    $.get('/api/Compras/pedidos/enviar/', function(dato) {
        var html_select ='';
     html_select +='<tr >';
     html_select +='<td>'+dato[0].id+'</td>';
     html_select +='<td>hola funciono </td>';
     html_select +='<td >'+dato[0].cantidad+'</td class="tdtotal">';
     html_select +='<td>0</td></tr>';
     $('#tablareporte').append(html_select);     
});
}
function enviarid(){
    var html_select ='';
    html_select +='<tr>';
    html_select +='<td>hola</td>';
    html_select +='<td>hola funciono </td>';
    html_select +='<td >vamosbien</td class="tdtotal">';
    html_select +='<td>0</td></tr>';
    $('#tablareporte').append(html_select);  
}