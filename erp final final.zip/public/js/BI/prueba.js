var i=0;
$(".new-campaign" ).sortable({
    handle: ".prov",
    cancel: ".panel-toggle,input",
    placeholder: "panel-placeholder",
    containment: "document",
    delay: 150,
    opacity: .75,
    revert: 50,
    scroll: false,
    start: function(e, ui){
      ui.placeholder.height(ui.item.height());    
    }
  });
  $('#body').on('click',".btn-danger", eliminar);
  $(document).on('click',".valores", obtenerid);
  $('#idcubo').on('change', selectcubo);
  //$('#ulbody').on('drag',".draggable");
  
 function obtenerid(){
var g= $(this).val();
 conosole.log("hola");

 } 
function eliminar(){
    $(this).parent().parent().parent().remove();
}

  $( ".draggable" ).draggable({
    connectToSortable: ".new-campaign",
    handle: ".prov",
    cancel: ".panel-toggle",
    containment: "document",
    delay: 150,
    opacity: .75,
    revert: "invalid",
    stack: ".draggable",
    helper: function(e) {
      var clone = $(this).clone();
      var p2=clone.attr("id");
      var p3=clone.children().attr("id");
   
      var html_p='<button type="submit" class="btn btn-danger" style="width:20px; height:10px"></button><label>'+p3+'</label>';
     //clone.append(html_p);
      //   var valo = $(this).parent().parent().attr("id");
  clone.removeAttr("style");
   i++;
   var idn= "nro"+i;
        clone.children().children().attr("id",idn);
     clone.children().children().html(html_p);
        clone.width($( ".new-campaign" ).width()); //fix the size of the dragged message
      console.log(p2);
      console.log(p3);
      
      return clone;
    }
  });

  $( '#workspace' ).on('click', '.panel-toggle', function() {
    $(this).toggleClass( "fa-minus fa-plus" );
  });
/////////////ahora vamos a hacer contacto con los espiritus tableross
 function selectcubo(){
     var eleccion=$(this).val();
     

if(eleccion==1){

  var html_q=''; 
   html_q += '<li id="proveedors" ><ul id="menubi">';
   html_q += '<li><input type="checkbox" name="list" id="nivel1-1"><label id="labeln" for="nivel1-1">Proveedor</label>';
   html_q += ' <ul class="interior">';

   html_q += '    <li  id="proveedors" class="draggable" >';
   html_q += '    <div id="nombre"><div class="prov">';
   html_q += '       <label for="">Nombre</label>';
   html_q += '           <input type="hidden" id="tablapn" class="valores" name="tablapn" value="proveedors"/>';
   html_q += '           <input type="hidden" id="atributopn" class="valores" name="atributopn" value="nombre"/>';
   html_q += '       </div></div></li>';



   html_q += '        <li  id="Proveedor" class="draggable" ><div id="direccion"><div class="prov">';
   html_q += '       <label for="">Direccion</label>';
   html_q += '           <input type="hidden" id="tablapd" class="valores" name="tablapd" value="proveedors"/>';
   html_q += '           <input type="hidden" id="atributopd" class="valores" name="atributopd" value="direccion"/>';
   html_q += '       </div></div></li></ul></li>';
   html_q += '</ul></li>';

}

if(eleccion==2){
    
}

if(eleccion==3){
    
}
$('#ulbody').html(html_q);
 }
