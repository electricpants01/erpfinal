var j=0;
//var k=0;
$(function(){
    $('#idcubo').on('change', selectcubo);
// $('#Bsalir').on('click', eliminar);
// $("tbody").on("click",".btn-danger", elminarfila);
// $('#Bguardar').on('click', guardarDatos);
 /*$("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Benviar').on('click', enviarDatos);
*/
 newFunction();
 newFunction2();
 $( "#droppable" ).on('drop', droppear);
 $( "#filas" ).on('drop', droppearfila);

});

/*$( function() {
    $( "#draggable" ).draggable();
    $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );
      }
    });
  } );
*/
  function droppear( event, ui ) {
    $element = ui.helper.clone();
  //  $element.draggable();
   // $element.selectable();
    $element.appendTo(this);

  //  var id = ui.draggable.attr("name");
   // $( this ).addClass( "ui-state-highlight" ).html( id );
  }
  function droppearfila( event, ui ) {
    var id = ui.draggable.attr("id");
    var elem = ui.helper.clone();
    var html_select='';
    html_select= '<input type="number" id="imnro" class="form-control imput" placeholder="" name="imnro" value="10" readonly="readonly">';


    $( this ).addClass( "ui-state-highlight" );
    $("#columnas").html(elem);
  }

function newFunction(){

    console.log("hola");
}
function selectcubo(){

}
function newFunction2(){
 // Dar a las imágenes la capacidad de mover las imágenes
 //$("#nivel1-1").draggable();
 //$("#nivel2-1").draggable();
 /*$("#n1").draggable({
    containment: '#filas',
    cursor: 'move',
    helper: draggableInputHelper,
  });*/
 $("#n1").draggable({
 cursor: 'move',});
 $("#filas").droppable();
 $( "#droppable").droppable();
 console.log("hola2");
 $( "#draggable" ).draggable();
 // Damos la capacidad al div de recibir a otros elementos, admitiendo sólo a la imagen
// cuyo 'id' es 'arrastrar2', y con la condición de que sea soltada estando completamente dentro
 //$("#filas").droppable( {accept:"#n1", tolerance:"fit", drop:elementoSoltado });
}
// ------------------------------
// Al haber definido la propiedad 'accept' para que admita sólo la imagen del logo, no
// se producirá efecto alguno si soltamos la otra imagen al no ser admitida.
function elementoSoltado( event, ui )
{
 var id = ui.draggable.attr("id");
 $("#columnas").text("La imagen con id [" + id + "] ha sido soltada y aceptada");
}


function draggableInputHelper(event) {
    return 'clonacion';
  }
 