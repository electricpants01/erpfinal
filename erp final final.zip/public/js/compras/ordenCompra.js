var j=0;
//var k=0;
$(function(){
    $('#idped').on('change', selectped);
 $('#Bsalir').on('click', eliminar);
 $("tbody").on("click",".btn-danger", elminarfila);
 $('#Bguardar').on('click', guardarDatos);
 $('#divform').on('click',"#Bvolver", volverAtras);
 $('#divform').on('click',"#Bestado", Guardarestado);
 
 $("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 $('#idpedestado').on('change', selectpedd);
 //$('#Bvolver').on('click', volverAtras);
 
 //$('#Bguardado').on('click', Datosguardados);
 $('#Benviar').on('click', enviarDatos);
 newFunction();
});


function  enviarDatos(){
    $.post("/dashboard/Compras/CompraProv/mail",$("#pedidoprov").serialize(),function(x){
        var boton = document.getElementById("Benviar");
        boton.disabled = true;
        alert("Correo enviado "+ x);
       console.log(j);
    });
    }

function newFunction() {
    var boton2 = document.getElementById("Benviar");
    boton2.disabled = true;
}
function selectped(){
    var id_ped = $(this).val();
     j = j+1;
    //ajax
    var html_select ='';
   
      $.get('/api/Compras/compraProv/'+id_ped+'', function(dato) {
          j=0;
        for(var i=0 ;i< dato.length ;i++){
            j=j+1;
            html_select +='<tr id="tr'+j+'" value="'+j+'" class="seleccion"><td><button type="submit" class="btn btn-danger">X</button></td>';
        html_select +='<td >'+dato[i].nombre+'<input type="hidden" id="tdnombre'+j+'" name="tdnombre'+j+'" value="'+dato[i].id+'" /> </td>';
        html_select +='<td> <input type="number" id="imnro'+j+'" class="form-control imput" placeholder="" name="imnro'+j+'" value="'+dato[i].cantidad+'" ></td>';
        html_select +='<td id="tdprecio'+j+'">'+dato[i].precio+'<input type="hidden"  id="itdprecio'+j+'" name="itdprecio'+j+'" value="'+dato[i].precio+'" /> </td class="tdtotal">';
        html_select +='<td id="tdnro'+j+'">'+dato[i].sub_total+'<input type="hidden"  id="itdtotal'+j+'" name="itdtotal'+j+'" value="'+dato[i].sub_total+'" /> </td></tr>';
        $('#tdprod').html(html_select);
     //   console.log(j);
        } 
     console.log(j);
     calculartotal(j);
     $('#tdprod').val(j);
     $('#idpedido').val(id_ped);
     
    });
   //console.log(k);
}

function calculartotal(k){
    var sumtotal =0;
    var cantotal=0;
 for(var i=1; i<=k;i++){
     if($('#itdtotal'+i).val()){
         sumtotal =Number(sumtotal) + Number($('#itdtotal'+i).val());
     }
     if($('#imnro'+i).val()){
        cantotal =Number(cantotal) + Number($('#imnro'+i).val());
    }
 }
 $('#sumatotal').val(sumtotal);
 $('#canttotal').val(cantotal);
 console.log(sumtotal);
}

function elminarfila(){
    var n= $('#tdprod').val();
    $(this).parent().parent().remove();
    calculartotal(n);
   }


   function guardarDatos(){
    var n= $('#tdprod').val();
    $('#valorj').val(n);
    var boton = document.getElementById("Bguardar");
   if(validaForm()){  
    $.post("/dashboard/Compras/CompraProv/agregar",$("#pedidoprov").serialize(),function(res){
        if(res){
        console.log("el valor de prov es"+res);
        alert("Pedido Guardado Exitosamente. ");
        boton.disabled = true;
        var boton2 = document.getElementById("Benviar");
    boton2.disabled = false;
      $("#idpedido").val(res);
    }
        else{ alert("error el pedido no se ah podido guardar");}
    });
   }else{console.log("fracaso");}
    
 }
 function validaForm(){
    // Campos de texto
    var n= $('#tdprod').val();
    for(var i=0 ;i<=n;i++){
      if($("#imnro"+i).val() == ""){
         alert("El campo cantidad no puede estar vacío.");
         $("#imnro"+i).focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
          return false;
        }else if($('#iddprov').val()==""){
            alert("El Proveedor no puede estar vacío.");
            $("#iddprov").focus(); 
          return false;
        }
    }
    return true; // Si todo está correcto
}
function eliminar(){
    $.post("/dashboard/Compras",$("#pedidoprov").serialize());
}

function filatotal(){
    var htm ="";
     var precio=0;
    var valorinput=$(this).val();
    var valo = $(this).parent().parent().attr("id");
    var valorr=$('#tdnombre'+valo[2]).val();
    console.log(valorr);
  
  $.get('/api/Compras/pedidoProv/'+valorr+'', function(dato) {
   precio = dato[0].costo_actual;
   valorinput = valorinput * precio;
   htm +='<td id="tdnro'+valo[2]+'">'+valorinput+'<input type="hidden" id="itdtotal'+valo[2]+'" name="itdtotal'+valo[2]+'" value="'+valorinput+'" /> </td>'
   $('#tdnro'+valo[2]).remove();
  $('#tr'+valo[2]).append(htm);
  console.log(valorinput);
  var n= $('#tdprod').val();
  calculartotal(n);
  });
}

function selectpedd() {
    var id_ped = $(this).val();
    var html_select ='';
    j= $(this).val();
      $.get('/api/Compras/compraProv/'+id_ped+'', function(dato) {
        html_select +='<button type="button" id="Bestado" class="btn btn-primary">Guardar</button>'; 
        html_select +='<button type="button" id="Bvolver" class="btn btn-danger">Salir</button><br><br>';
        html_select +=' <input type="hidden" id="idestadoped" name="idestadoped" value="'+j+'"/>';
        html_select +=' <label class="control-label">Cambiar estado de Pedido: </label> <select name="idpedestado" id="idpedestado" >';
            html_select +='<option value="">Selecciona el estado</option>';
            html_select +='<option value="1">Aceptado</option>';
            html_select +='<option value="2">Rechazado</option><br><br>';   
            $('#divform').html(html_select);
    });
}
 function volverAtras(){
    window.history.back()
 }

 function Guardarestado(){
    if(validaForme()){  
       $.post("/dashboard/Compras/ePedidoProv/cambiarEstado",$("#pedidoprov").serialize(),function(res){
            if(res){
            console.log("el valor de prov es"+res);
            alert("Estado Cambiado Exitosamente. ");
            window.history.back();
        }
            else{ alert("error el pedido no se ah podido guardar");}
        });
       }else{console.log(j);}

 }

 
 function validaForme(){
      if($('#idpedestado').val()==""){
            alert("Seleccione un estado de pedido.");
            $("#idpedestado").focus(); 
          return false;
        }
    return true; // Si todo está correcto
}