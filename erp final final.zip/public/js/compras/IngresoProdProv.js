var j=0;
//var k=0;
$(function(){
   $('#idcompra').on('change', selectcompra);
// $('#Bsalir').on('click', eliminar);
 //$("tbody").on("click",".btn-danger", elminarfila);
 $('#Bguardar').on('click', guardarDatos);
 /*$("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Benviar').on('click', enviarDatos);
 */
 //newFunction();
});

function guardarDatos(){
    if(validaForm()){  
       $.post("/dashboard/Compras/IngresoProv/agregar",$("#pedidoprov").serialize(),function(res){
            if(res){
            console.log("el valor de prov es"+res);
            alert("Producto Guardado Exitosamente. ");
            //window.history.back();
            var boton = document.getElementById("Bguardar");
            boton.disabled = true;
        }
            else{ alert("error el producto no se ah podido guardar");}
        });
       }else{console.log(j);}

 }

function selectcompra(){
    var id_compra = $(this).val();
     j = j+1;
    //ajax
    var html_select ='';
    console.log(id_compra);
      $.get('/api/Compras/IngresoProv/'+id_compra+'', function(dato) {
          j=0;
        for(var i=0 ;i< dato.length ;i++){
            j=j+1;
            html_select +='<tr id="tr'+j+'" value="'+j+'" class="seleccion"><td></td>';
        html_select +='<td >'+dato[i].nombre+'<input type="hidden" id="tdnombre'+j+'" name="tdnombre'+j+'" value="'+dato[i].id+'" /> </td>';
        html_select +='<td> <input type="number" id="imnro'+j+'" class="form-control imput" placeholder="" name="imnro'+j+'" value="'+dato[i].cantidad+'" readonly="readonly"></td>';
        html_select +='<td id="tdprecio'+j+'">'+dato[i].costo+'<input type="hidden"  id="itdprecio'+j+'" name="itdprecio'+j+'" value="'+dato[i].costo+'" /> </td class="tdtotal">';
        html_select +='<td id="tdnro'+j+'">'+dato[i].costo_sub_total+'<input type="hidden"  id="itdtotal'+j+'" name="itdtotal'+j+'" value="'+dato[i].costo_sub_total+'" /> </td></tr>';
        $('#tdprod').html(html_select);
     //   console.log(j);
        } 
     console.log(j);
     calculartotal(j);
     $('#tdprod').val(j);
     $('#valorj').val(j);
     $('#idcompraval').val(id_compra);
     
    });
   //console.log(k);
}

function calculartotal(k){
    var sumtotal =0;
    var cantotal=0;
 for(var i=1; i<=k;i++){
     if($('#itdtotal'+i).val()){
         sumtotal =Number(sumtotal) + Number($('#itdtotal'+i).val());
     }
     if($('#imnro'+i).val()){
        cantotal =Number(cantotal) + Number($('#imnro'+i).val());
    }
 }
 $('#sumatotal').val(sumtotal);
 $('#canttotal').val(cantotal);
 console.log(sumtotal);
}
function validaForm(){
    if($('#idcompra').val()==""){
          alert("Seleccione una compra.");
          $("#idpedestado").focus(); 
        return false;
      }
  return true; // Si todo está correcto
}