var j=0;
//var k=0;
$(function(){
    $('#iddevolucion').on('change', selectdevolucion);
// $('#Bsalir').on('click', eliminar);
// $("tbody").on("click",".btn-danger", elminarfila);
 $('#Bguardar').on('click', guardarDatos);
 /*$("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Benviar').on('click', enviarDatos);
*/
 //newFunction();
});

function selectdevolucion(){
    var id_dev = $(this).val();
    j = j+1;
   //ajax
   var html_select ='';
   console.log(id_dev);
     $.get('/api/Compras/devolucion/'+id_dev+'', function(dato) {
         j=0;
       for(var i=0 ;i< dato.length ;i++){
           j=j+1;
           html_select +='<tr id="tr'+j+'" value="'+j+'" class="seleccion"><td></td>';
       html_select +='<td >'+dato[i].nombre+'<input type="hidden" id="tdnombre'+j+'" name="tdnombre'+j+'" value="'+dato[i].id+'" /> </td>';
       html_select +='<td> <input type="number" id="imnro'+j+'" class="form-control imput" placeholder="" name="imnro'+j+'" value="'+dato[i].cantidad+'" readonly="readonly"></td>';
       html_select +='<td id="tdprecio'+j+'">'+dato[i].costo+'<input type="hidden"  id="itdprecio'+j+'" name="itdprecio'+j+'" value="'+dato[i].costo+'" /> </td class="tdtotal">';
       html_select +='<td id="tdnro'+j+'">'+dato[i].sub_total+'<input type="hidden"  id="itdtotal'+j+'" name="itdtotal'+j+'" value="'+dato[i].sub_total+'" /> </td></tr>';
       $('#tdprod').html(html_select);
    //   console.log(j);
       } 
       var  html_ot="";
       html_ot+='<label class="control-label">Estado de devolucion:</label> <select name="iddevo" id="iddevo" >';
       html_ot+='<option value="">Seleccione opcion</option>';
       html_ot+='<option value="1">Aceptado</option>';
       html_ot+='<option value="2">Rechazado</option></select>';
       $('#selector').html(html_ot);
    console.log(j);
    calculartotal(j);
    $('#tdprod').val(j);
    $('#valorj').val(j);
    $('#iddev').val(id_dev);
    
   });
  //console.log(k);
}
function calculartotal(k){
    var sumtotal =0;
    var cantotal=0;
 for(var i=1; i<=k;i++){
     if($('#itdtotal'+i).val()){
         sumtotal =Number(sumtotal) + Number($('#itdtotal'+i).val());
     }
     if($('#imnro'+i).val()){
        cantotal =Number(cantotal) + Number($('#imnro'+i).val());
    }
 }
 $('#sumatotal').val(sumtotal);
 $('#canttotal').val(cantotal);
 console.log(sumtotal);
}
function validaForm(){
    if($('#iddevo').val()==""){
          alert("Seleccione un estado de devolucion.");
          $("#iddevo").focus(); 
        return false;
      }
  return true; // Si todo está correcto
}

function guardarDatos(){
    $('#valorj').val(j);
   if(validaForm()){  
    $.post("/dashboard/Compras/estadoDevolucion/agregar",$("#pedidoprov").serialize(),function(res){
        if(res){
        console.log("el valor de prov es"+res);
        alert("Devolucion Guardada Exitosamente. ");
        
        window.history.back();
    }
        else{ alert("error el pedido no se ah podido guardar");}
    });
   }else{console.log("fracaso");}
    
 }
