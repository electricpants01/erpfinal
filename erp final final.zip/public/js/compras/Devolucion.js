var j=0;
//var k=0;
$(function(){
    $('#idcompra').on('change', selectcompra);
 $('#Bsalir').on('click', eliminar);
 $("tbody").on("click",".btn-danger", elminarfila);
 $('#Bguardar').on('click', guardarDatos);
 $("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Benviar').on('click', enviarDatos);

 //newFunction();
});


function  enviarDatos(){
    $.post("/dashboard/Compras/Devolucion/mail",$("#pedidoprov").serialize(),function(x){
        var boton = document.getElementById("Benviar");
        boton.disabled = true;
        alert("Correo enviado "+ x);
       console.log(j);
    });
    }

function guardarDatos(){
    $('#valorj').val(j);
    var boton = document.getElementById("Bguardar");
   if(validaForm()){  
    $.post("/dashboard/Compras/Devolucion/agregar",$("#pedidoprov").serialize(),function(res){
        if(res){
        console.log("el valor de prov es"+res);
        alert("Devolucion Guardada Exitosamente. ");
        boton.disabled = true;
        var boton2 = document.getElementById("Benviar");
    boton2.disabled = false;
      $("#idpedido").val(res);
    }
        else{ alert("error el pedido no se ah podido guardar");}
    });
   }else{console.log("fracaso");}
    
 }
 function validaForm(){
    // Campos de texto
    for(var i=0 ;i<=j;i++){
      if($("#imnro"+i).val() == ""){
         alert("El campo cantidad no puede estar vacío.");
         $("#imnro"+i).focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
          return false;
        }
        if($("#imnro"+i).val() == 0){
            alert("Elimine el campo con cantidad 0 o agrege valor.");
            $("#imnro"+i).focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
             return false;
           }
           if($("#imnro"+i).val() < 0){
            alert("No se permiten valores negativos");
            $("#imnro"+i).focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
             return false;
           }
    }
    return true; // Si todo está correcto
}

function selectcompra(){
    var id_compra = $(this).val();
    j = j+1;
   //ajax
   var html_select ='';
   console.log(id_compra);
     $.get('/api/Compras/IngresoProv/'+id_compra+'', function(dato) {
         j=0;
       for(var i=0 ;i< dato.length ;i++){
           j=j+1;
           html_select +='<tr id="tr'+j+'" value="'+j+'" class="seleccion"><td><button type="submit" class="btn btn-danger">X</button></td>';
       html_select +='<td >'+dato[i].nombre+'<input type="hidden" id="tdnombre'+j+'" name="tdnombre'+j+'" value="'+dato[i].id+'" /> </td>';
       html_select +='<td> <input type="number" id="imnro'+j+'" class="form-control imput" placeholder="" name="imnro'+j+'" value="'+dato[i].cantidad+'"></td>';
       html_select +='<td id="tdprecio'+j+'">'+dato[i].costo+'<input type="hidden"  id="itdprecio'+j+'" name="itdprecio'+j+'" value="'+dato[i].costo+'" /> </td class="tdtotal">';
       html_select +='<td id="tdnro'+j+'">'+dato[i].costo_sub_total+'<input type="hidden"  id="itdtotal'+j+'" name="itdtotal'+j+'" value="'+dato[i].costo_sub_total+'" /> </td></tr>';
       $('#tdprod').html(html_select);
    //   console.log(j);
       } 
    console.log(j);
    calculartotal(j);
    $('#tdprod').val(j);
    $('#valorj').val(j);
    $('#idcompraval').val(id_compra);
    
   });
  //console.log(k);
}
function calculartotal(k){
    var sumtotal =0;
    var cantotal=0;
 for(var i=1; i<=k;i++){
     if($('#itdtotal'+i).val()){
         sumtotal =Number(sumtotal) + Number($('#itdtotal'+i).val());
     }
     if($('#imnro'+i).val()){
        cantotal =Number(cantotal) + Number($('#imnro'+i).val());
    }
 }
 $('#sumatotal').val(sumtotal);
 $('#canttotal').val(cantotal);
 console.log(sumtotal);
}

function eliminar(){
    $.post("/dashboard/Compras",$("#pedidoprov").serialize());
}

function elminarfila(){

    $(this).parent().parent().remove();
    calculartotal(j);
   }
   
function filatotal(){
    var htm ="";
     var precio=0;
    var valorinput=$(this).val();
    var valo = $(this).parent().parent().attr("id");
    var idproduct= $('#tdnombre'+valo[2]).val();
  $.get('/api/Compras/pedidoProv/'+idproduct+'', function(dato) {
   precio = dato[0].costo_actual;
   valorinput = valorinput * precio;
   htm +='<td id="tdnro'+valo[2]+'">'+valorinput+'<input type="hidden" id="itdtotal'+valo[2]+'" name="itdtotal'+valo[2]+'" value="'+valorinput+'" /> </td>'
   $('#tdnro'+valo[2]).remove();
  $('#tr'+valo[2]).append(htm);
  calculartotal(j);
  });
  console.log(valorinput);
  console.log(valo[2]);
  console.log(idproduct);
  
  
}
