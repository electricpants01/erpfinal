 productos= new Array(25);
 var j=0;

$(function(){
    $('#idprod').on('change', selectprod);
 $('#Bsalir').on('click', eliminar);
 $("tbody").on("click",".btn-danger", elminarfila);
 $("body").on("keyup","input", filatotal);
 $("body").on("change","input", filatotal);
 //$('#Bguardado').on('click', Datosguardados);
 $('#Bguardar').on('click', guardarDatos);
 $('#Benviar').on('click', enviarDatos);
 
 newFunction();
 
});


function newFunction() {
    var boton2 = document.getElementById("Benviar");
    boton2.disabled = true;
}

function selectprod(){
 var id_prod = $(this).val();
  j = j+1;
 //ajax
 var html_select ='';

    $.get('/api/Compras/pedidoProv/'+id_prod+'', function(dato) {
     html_select +='<tr id="tr'+j+'" value="'+j+'" class="seleccion"><td><button type="submit" class="btn btn-danger">X</button></td>';
     html_select +='<td>'+dato[0].nombre+'<input type="hidden" id="tdnombre'+j+'" name="tdnombre'+j+'" value="'+dato[0].id+'" /> </td>';
     html_select +='<td> <input type="number" id="imnro'+j+'" class="form-control imput" placeholder="" name="imnro'+j+'"></td>';
     html_select +='<td id="tdprecio'+j+'">'+dato[0].costo_actual+'<input type="hidden"  id="itdprecio'+j+'" name="itdprecio'+j+'" value="'+dato[0].costo_actual+'" /> </td class="tdtotal">';
     html_select +='<td id="tdnro'+j+'">0<input type="hidden"  id="itdtotal'+j+'" name="itdtotal'+j+'" value="'+0+'" /> </td></tr>';
     $('#tdprod').append(html_select);    
     productos[j]= dato[0].id; 
});
}

function filatotal(){
    var htm ="";
     var precio=0;
    var valorinput=$(this).val();
    var valo = $(this).parent().parent().attr("id");
  
  $.get('/api/Compras/pedidoProv/'+productos[valo[2]]+'', function(dato) {
   precio = dato[0].costo_actual;
   valorinput = valorinput * precio;
   htm +='<td id="tdnro'+valo[2]+'">'+valorinput+'<input type="hidden" id="itdtotal'+valo[2]+'" name="itdtotal'+valo[2]+'" value="'+valorinput+'" /> </td>'
   $('#tdnro'+valo[2]).remove();
  $('#tr'+valo[2]).append(htm);
  calculartotal();
  });
}
function elminarfila(){

 $(this).parent().parent().remove();
 calculartotal();
}
function guardarDatos(){
    $('#valorj').val(j);
    var boton = document.getElementById("Bguardar");
   if(validaForm()){  
    $.post("/dashboard/Compras/PedidoProv/agregar",$("#pedidoprov").serialize(),function(res){
        if(res){
        console.log("el valor de prov es"+res);
        alert("Pedido Guardado Exitosamente. ");
        boton.disabled = true;
        var boton2 = document.getElementById("Benviar");
    boton2.disabled = false;
      $("#idpedido").val(res);
    }
        else{ alert("error el pedido no se ah podido guardar");}
    });
   }else{console.log("fracaso");}
    
 }
 function validaForm(){
    // Campos de texto
    for(var i=0 ;i<=j;i++){
      if($("#imnro"+i).val() == ""){
         alert("El campo cantidad no puede estar vacío.");
         $("#imnro"+i).focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
          return false;
        }else if($('#iddprov').val()==""){
            alert("El Proveedor no puede estar vacío.");
            $("#iddprov").focus(); 
          return false;
        }
    }
    return true; // Si todo está correcto
}

function calculartotal(){
    var sumtotal =0;
    var cantotal=0;
 for(var i=1; i<=j;i++){
     if($('#itdtotal'+i).val()){
         sumtotal =Number(sumtotal) + Number($('#itdtotal'+i).val());
     }
     if($('#imnro'+i).val()){
        cantotal =Number(cantotal) + Number($('#imnro'+i).val());
    }
 }
 $('#sumatotal').val(sumtotal);
 $('#canttotal').val(cantotal);
}
function  enviarDatos(){
$.post("/dashboard/Compras/PedidoProv/mail",$("#pedidoprov").serialize(),function(x){
    var boton = document.getElementById("Benviar");
    boton.disabled = true;
    alert("Correo enviado "+ x);
   console.log(j);
});
}
function Datosguardados(){
    alert("el pedido ya se ah guardado anteriormente");
}
function eliminar(){
    $.post("/dashboard/Compras",$("#pedidoprov").serialize());
}

function objetoAjax(){
    var xmlhttp = false;
     try { 
         xmlhttp = new ActiveXObejct("Msxml2.XMLHTTP");
     }catch (e){
         try {
            xmlhttp = new ActiveXObejct("Microsoft.XMLHTTP");
         } catch(E){
         xmlhttp = false;
     }
    }
     if (!xmlhttp && typeof XMLHttpRequest!= "undefined"){
         xmlhttp = XMLHttpRequest();
     }
     return xmlhttp;
}

