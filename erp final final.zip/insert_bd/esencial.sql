


-- usuarios admistrativos

insert into users (name,email,email_verified_at,password ) values 
	('julio','hulk@jul.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('pedro','pedro@pedro.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('lucas','lucas@lucas.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('elver','hulk@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('jorge el curioso','jorge@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('andres lopez','andre23@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('locto','locoto@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('christian','chris@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('fernando lopez','fer@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('andrea salazar','andrea435@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Tomate perede','tomate2@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Pepito perez','pepe56@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Pepote perez','pereto@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Estaban dido','esteban231@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Esteco suarez','esteco00@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Adele','adele666@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Ariana','ariana99@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('taylor Swift','taylor21@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Andrew','andre88@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Sammuel l jackson','sam55@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Robert de niro','robert@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Leonardo di caprio','leo@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('andrew foster','andrew67@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Batman ','batman@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Superman','superman@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Spiderman','spiderman@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Aquaman','aquaman@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Mujer maravilla','maravilla@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Capitan america','capitan@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('mario bros','mario@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Mandela lopez','mandela@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Android 23','android@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Julio profe','julius@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Pewdiepie','pewds@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Saw','saw@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Lorena lopez','lorena333@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Oiri yagami','oiri89@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Quentin Tarantino','quentin69@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('DR cerebro','cerebro2433@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Iori nogazawa','tori23@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Tolomeo ','toloemo@gmail.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja'),
	('Christian','admin@admin.com',now(),'$2y$10$1l.qBxeRjWPDEeTUPaiNj.lFtDk4Xm26vHO8aCt4qRbutJAPXBcja');
 
-- empleados

insert into empleados( nombre,apellido,direccion,email,telefono,ci,sexo,cargo) values
	('christian','torrico','urb los penocos','chris@chris.com','70873323','12345678','H','entrepretenuer');
	
-- forma de pagos

insert into forma_pagos(nombre) values ('pago por PayPal');

-- proveedores

insert into proveedors(nombre,nit,direccion,email,telefono,tipo,estado) values	
	('andres','12345678','2do anillo interno','andres@gmail.com','70012345','proveedor',1),
	('jorge','12364570','3er anillo externo','locoto@gmail.com','61234567','proveedor',1);
	
-- categoria_id
insert into categorias(nombre) values ('licores');

-- marcas
insert into marcas(nombre) values ('pil'),('huari'),('pacena'),('inca'),('imperial')
					,('heineken'),('malta'),('cordillera'),('crucena'),('artesana'),('frost'),('ducal'),
					('taquina');
-- productos 

insert into productos(nombre,costo_actual,cant_pedido,inventario_min,fecha_expiracion,descripcion,categoria_id,marca_id,imagen) values 
	('Ducal',12.5,1000,56,'2019/06/20','Cerveza de los años 50',1,12,'images/ducal.jpg'),
	('Maltin',2.3,25,26,'2019/06/22','Bebida malta',1,7,'images/maltin.jpg'),
	('Paceña',7.89,2500,300,'2019/07/30','Cerveza paceña la mejor cerveza',1,3,'images/pacena.jpg'),
	('Taquiña',13.5,650,60,'2019/08/03','Cerveza de la cordillera de tunari',1,13,'images/taquina.jpg'),
	('Paceña La Paz',8.1,800,50,'2019/07/05','Cerveza desde La Paz',1,3,'images/pacenalapaz.jpg'),
	('Paceña Ice',7.5,70,30,'2019/06/29','Cerveza super fria',1,3,'images/pacenaice.jpg'),
	('Paceña Centenario',6.5,600,50,'2019/06/28','Paceña centenario',1,3,'images/pacenacentenario.jpg'),
	('Paceña Rock',5.5,500,35,'2019/08/02','Cerveza para los rockeros',1,3,'images/pacenarock.jpg'),
	('Paceña Black',6.3,300,25,'2019/08/05','Ceveza Negra',1,3,'images/pacenablack.jpg'),
	('Imperial',4.3,300,30,'2019/07/07','Cerveza imperial',1,5,'images/imperial.jpg'),
	('Huari',15.2,999,100,'2019/08/08','Cerveza Huari',1,2,'images/huari.jpg'),
	('Inca',5.7,800,70,'2019/09/09','Cerveza Inca',1,4,'images/inca.jpg'),
	('Cruceña',14.4,800,80,'2019/08/09','fabricada en SC con poco grado de alcohol',1,9,'images/crucena.jpg'),
	('Real',7.7,500,50,'2019/09/01','bebida fresca creada por los bolivianos',1,7,'images/real.jpg'),
	('Corona',2.5,200,20,'2019/07/01','Cerveza Corona de 355ML',1,3,'images/corona.jpg'),
	('Malta',2.5,500,50,'2019/08/20','Malta Real Lata 350ML',1,7,'images/malta.jpg'),
	('Paceña Lata',3.8,600,60,'2019/08/03','Cerveza Paceña Lata 473ML',1,3,'images/pacenalata.jpg'),
	('Heineken',6.6,520,60,'2019/10/01','Cerveza Lata 335ML',1,6,'images/heineken.jpg'),
	('Pilsener',1.5,200,20,'2019/08/07','Cerveza Pilsener 350ML',1,1,'images/pilsener.jpg'),
	('Coordillera',8.8,400,40,'2019/09/09','Cerveza Cordillera 350ML',1,8,'images/cordillera.jpg'),
	('Cordillera Botella',4.5,80,20,'2019/07/15','Botella de 620ML',1,8,'images/cordillerabotella.jpg'),
	('Heineken Botella',12.2,642,100,'2019/08/06','Botella de 1 Litro',1,6,'images/heinekenbotella.jpg'),
	('Artesana Tostada',5.2,500,50,'2019/08/12','Botella de 300ML',1,10,'images/artesana.jpg'),
	('Artesana Cobriza',2.5,500,50,'2019/08/08','Botella de 300ML',1,10,'images/artesanacobriza.jpg'),
	('Artesana Dorada',4.5,7.5,70,'2019/07/23','Botella de 300ML',1,10,'images/artesanadorada.jpg'),
	('Six Pack Malta',5.5,700,70,'2019/07/07','6 latas de 350ML',1,7,'images/maltapack.jpg'),
	('Frost',4.2,423,45,'2019/08/07','Cerveza Premium de 355ML',1,11,'images/frost.jpg');
	
	
	
-- sucursales

insert into sucursals(nombre,direccion,telefono,departamento,estado) values	
	('Super 4to anillo','Tres pasos al frente','70012345','Santa Cruz',1),
	('Super 2do anillo','Av beni','67123556','Santa Cruz',1);
	
-- almacenes verificar valor y cantidad
insert into almacens(direccion,telefono,valor_almacenado,cantidad,sucursal_id) values
	('Tres pasos al frente calle 5','60012344',5933252.5,5936,1),
	('Av Beni calle 3','70014266',4325664.4,2653,2);
	
-- Almacen-Productos
insert into almacen_productos(nombre,descripcion,cantidad,costo_actual,imagen,almacen_id,producto_id,devolucion)
select nombre,descripcion,productos.cant_pedido,costo_actual,imagen,1,id,(costo_actual-costo_actual)
from productos

	