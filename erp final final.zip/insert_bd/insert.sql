
use erp3;


insert into users(name,email,email_verified_at,password) values ('Christian','admin@admin.com',now(),'$2y$12$y81TZhJNIP1uVpU4uZl9qOZA5fqSb76CNo6EmZneT9hzDSwggDO5i')

-- insertar a categoria y marca

insert into marcas(nombre) values ('pil'),('huari'),('pacena'),('inca'),('imperial')
					,('heineken'),('malta'),('cordillera'),('crucena'),('artesana'),('frost'),('ducal'),
					('taquina')
					

insert into productos(nombre,costo_actual,cant_pedido,inventario_min,fecha_expiracion,descripcion,categoria_id,marca_id) values 
('coca cola',12.2,20,30,'2019-05-22','simple cola',1,1);					