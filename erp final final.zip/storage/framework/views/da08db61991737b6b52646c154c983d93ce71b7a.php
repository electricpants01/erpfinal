<?php $__env->startSection('content'); ?>

<div class="container">
  <h2>Crear Marca o Categoria</h2><br>
  <form action="<?php echo e(route('marca')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
  <label for="text">Primero seleccione a que tabla quiere insertar:</label><br>
      <select name="tabla">
        <option value="">INSERTAR A:</option>
        <option value="1">Marca</option>
        <option value="2">Categoria</option>
      </select>
    </div>
    <div class="form-group">
      <label for="text">Nombre:</label>
      <input type="text" class="form-control"  placeholder="Introduzca el nombre" name="nombre">
    </div>
    
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\base-erp\resources\views/almacen/marca.blade.php ENDPATH**/ ?>