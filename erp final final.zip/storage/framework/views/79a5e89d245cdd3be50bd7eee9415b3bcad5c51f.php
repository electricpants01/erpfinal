<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('css/dashboard/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('css/dashboard/bootstrap.js')); ?>"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Super ERP </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo e(route('dashboard')); ?>">Inicio</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Reporte Dinamico <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="<?php echo e(route('ventasreporte')); ?>">Hacer Reporte PDF</a></li>
          <li><a href="<?php echo e(route('ventasreportehtml')); ?>">Hacer Reporte HTML</a></li>
        </ul>
      </li>
      
      
    </ul>
  </div>
</nav>

<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">

    </div>
    <div class="col-sm-8 text-left"> 


        <?php echo $__env->yieldContent('content'); ?>



    </div>
    <div class="col-sm-2 sidenav">
    </div>
  </div>
</div>


</body>
</html><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/ventas/index.blade.php ENDPATH**/ ?>