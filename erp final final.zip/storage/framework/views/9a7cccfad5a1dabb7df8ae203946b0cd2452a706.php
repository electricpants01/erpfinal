


<?php $__env->startSection('content'); ?>



<div class="container">
  <h2>Crear Nuevo Producto </h2><br>
  <form action="<?php echo e(route('crearproducto')); ?>" method="POST">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <label >Nombre del Producto:</label>
      <input type="text" class="form-control" placeholder="La direccion del almacen" name="nombre">
    </div>
    <div class="form-group">
      <label >Costo:</label>
      <input type="text" class="form-control" placeholder="Costo del producto en dolares" name="costo">
    </div>
    <div class="form-group">
      <label >Cantidad:</label>
      <input type="text" class="form-control" placeholder="Cantidad del producto" name="cantidad">
    </div>
    <div class="form-group">
      <label >Iventario minimo:</label>
      <input type="text" class="form-control" placeholder="Cantidad del producto" name="inventario_min">
    </div>
    <div class="form-group">
      <label >Fecha de expiracion:</label>
      <input type="date"  name="fecha">
    </div>
    <div class="form-group">
      <label >Descripcion:</label>
      <input type="text" class="form-control" placeholder="Una breve descripcion del producto" name="descripcion">
    </div>

    <div class="form-group">
      <label >Categoria:</label>
      <select name="categoria" >
        <option value="">Selecciona la categoria</option>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label >Marca:</label>
      <select name="marca" >
        <option value="">Selecciona la marca</option>
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/app/current/resources/views/almacen/productoform.blade.php ENDPATH**/ ?>