<?php $__env->startSection('content'); ?>

<script>
    $(document).ready(function(){
        // ocultando los div
        $('#factura').hide();
        $('#filfact').hide();
        $('#fact_monto').hide();
        $('#fact_montoneto').hide();
        $('#fact_fecha').hide();
        $('#venta').hide();
        $('#filven').hide();
        $('#ven1').hide();
        $('#ven2').hide();
        $('#ven3').hide();
        $('#fildet').hide();
        $('#detalle_venta').hide();
        $('#det1').hide();
        //
        $('#tablas').change(function(){
            var sel = $(this).val();
            if( sel == 'facturas') $('#factura').show();
            if( sel == 'ventas') $('#venta').show();
            if( sel == 'detalle_ventas') $('#detalle_venta').show();
        });
        //
        $('#facturacol').change(function(){
            var sel = $(this).val();
            console.log(sel);
            $('#filfact').show();
            if( sel == 'monto') $('#fact_monto').show();
            if( sel == 'monto_neto') $('#fact_montoneto').show();
            if( sel == 'fecha') $('#fact_fecha').show();
        });
        //
        $('#ventacol').change(function(){
            var sel = $(this).val();
            $('#filven').show();
            console.log(sel);
            if( sel == 'cantidad') $('#ven1').show();
            if( sel == 'monto') $('#ven2').show();
            if( sel == 'fecha') $('#ven3').show();
        });
        $('#detalle_ventascol').change(function(){
            var sel = $(this).val();
            $('#fildet').show();
            if( sel == 'precio') $('#det1').show();
        });
    });
</script>


    <form action="<?php echo e(route('creareportehtml')); ?>" method="POST">
        <?php echo e(@csrf_field()); ?>

        <select class="selectpicker" name="tablas[]" id="tablas" multiple>
        <option value="facturas">Facturas</option>
        <option value="ventas">Ventas</option>
        <option value="detalle_ventas">Detalle de Ventas</option>
        </select> <hr>

        <div id="factura">
            <h2>Factura columnas</h2>
            <select class="selectpicker" name="facturacols[]" id="facturacol" multiple>
            <option value="id">ID factura</option>
            <option value="monto">Monto</option>
            <option value="iva">IVA</option>
            <option value="monto_neto">Monto Neto</option>
            <option value="fecha">Fecha</option>
            </select>
        </div>

        <h2 id="filfact">Filtrado de Factura</h2>
        <div id="fact_monto">Rango de monto: Entre <input type="text" name="fact_monto1" size="15"> Y <input type="text" name="fact_monto2"></div><br>
        <div id="fact_montoneto">Rango de monto NETO: Entre <input type="text" name="fact_montoneto1" size="15"> Y <input type="text" name="fact_montoneto2"></div><br>
        <div id="fact_fecha">Fecha de busqueda <input type="date" name="fact_fecha"></div>
        <hr>
        <!-- fin de la primera tabla -->
        <div id="venta">
            <h2>Venta columnas</h2>
            <select class="selectpicker" name="ventacols[]" id="ventacol" multiple>
            <option value="id">ID Venta</option>
            <option value="cantidad">cantidad</option>
            <option value="monto">monto</option>
            <option value="fecha">Fecha</option>
            </select>
        </div>

        <h2 id="filven">Filtrado de Venta</h2>
        <div id="ven1">Rango de venta: Entre <input type="text" name="venta_cantidad1" size="15"> Y <input type="text" name="venta_cantidad2"></div><br>
        <div id="ven2">Rango de monto : Entre <input type="text" name="venta_monto1" size="15"> Y <input type="text" name="venta_monto2"></div><br>
        <div id="ven3">Fecha de busqueda <input type="date" name="venta_fecha"></div>
        <hr>
        <!-- fin de la segunda tabla -->
        <div id="detalle_venta">
            <h2>Detalle de Ventas columnas</h2>
            <select class="selectpicker" name="detalle_ventascols[]" id="detalle_ventascol" multiple>
            <option value="id">ID Detalle</option>
            <option value="cantidad">cantidad</option>
            <option value="precio">precio</option>
            </select>
        </div>

        <h2 id="fildet">Filtrado de Detalle de Ventas</h2>
        <div id="det1">Rango de precio: Entre <input type="text" name="det_precio1" size="15"> Y <input type="text" name="det_precio2"></div><br>
        <hr>
        <!-- fin de la tercera tabla -->

        <input type="submit" class="btn btn-success" value="Crear Reporte">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ventas.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/ventas/reportehtml.blade.php ENDPATH**/ ?>