<?php $__env->startSection('content'); ?>
<div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
<h1>Tu carrito del Super </h1>
      <table class="table table-striped">
    <tbody>
    <tr>
        <th>Nombre del Producto</th>
        <th>Precio</th>
        <th>Cantidad</th>
    </tr>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->nombre); ?></td>
                <td><?php echo e($product->costo_actual); ?></td>
                <td><?php echo e($product->cantidad); ?></td>
            </tr>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
  </table>
  <h1>La suma del carrito es : <?php echo e($suma->suma); ?></h1>
  <h1>Envio Gratuito + IVA(13%) : <?php echo e($pagar); ?></h1>

  <!-- aqui va el metodo de pago -->
  <h2>Pago por PayPal </h2>
  <br>

  <div id="paypal-button-container"></div>
  
  <script
    src="https://www.paypal.com/sdk/js?client-id=AWrPZLukAz6W304d-dOPXvx7Gp93-iOl3T8uRIPa_k7ZgC6BXZxSJkCN2K1Qs7fB6vxfPnOXmEJ9TlmA">
  </script>

  <script>
  paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: '<?php echo e($pagar); ?>'
          }
        }]
      });
    },
    onApprove: function(data, actions) {
      // Capture the funds from the transaction
      window.location="<?php echo e(route('compracarrito')); ?>";
      return actions.order.capture().then(function(details) {
        // Show a success message to your buyer
        console.log('transaccion exitosa');
      });
    }
  }).render('#paypal-button-container');
</script>
</body>
  <!--hasta aqui -->
  <div class="col-sm-2 sidenav">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.superlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/user/carrito.blade.php ENDPATH**/ ?>