<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Example 1</title>
    <link rel="stylesheet" href="css/reportes/style.css" media="all" />
  </head>
  <body>
  
  <?php
     $prueb= "haber si esta sale";
     ?>
    <header class="clearfix">
      <div id="logo">
        <img src="css/reportes/imagen/logo.png">
      </div>
      <h1>PEDIDO DE PRODUCTOS</h1>
      <div id="company" class="clearfix">
        <div>Nombre de la Empresa: </div>
        <div>Sistemas ERP,<br /> AZ 85004, US</div>
        <div>(602) 519-0450</div>
        <div><a href="mailto:company@example.com">sistemaerp2@gmail.com</a></div>
      </div>
      <div id="project">
        <div><span>Cliente</span> <?php echo $prueb; ?></div>
        <div><span>Direccion</span>SANTA CRUZ DE LA SIERRA</div>
        <div><span>Fecha</span> August 17, 2015</div>
       
      </div>
    </header>
    <main>
      <div id="notices">
      </div>
    </main>
    <footer>
     nota depedido de productos al proveedor porfavor indicar lo mas pronto posible
    </footer>
  </body>
</html>

<script>
 $(function(){
  var html_select ='<h1>haber q paso</h1>';
    $('#tablareporte').append(html_select); 

   });

</script><?php /**PATH C:\xampp\htdocs\laravel\erpz\resources\views/reportes/vista.blade.php ENDPATH**/ ?>