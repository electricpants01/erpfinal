<?php $__env->startSection('content'); ?>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Super ERP</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Inicio</a></li>
        <li><a href="<?php echo e(route('indexCompras')); ?>">Compras</a></li>
        <li><a href="#">Ventas</a></li>
        <li><a href="<?php echo e(route('indexalmacen')); ?>">Almacen</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <form action="<?php echo e(route('adminlogout')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <input type="submit" class="btn btn-danger" value="Salir">
        </form>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Bienvenido <?php echo e(auth()->user()->name); ?></h1>      
    <p>Super ERP</p>
  </div>
</div>


<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading">Compras</div>
        <div class="panel-body"><img src="<?php echo e(asset('images/compras.jpg')); ?>" class="img-responsive" style="width:50%" alt="Image"></div>
        <div class="panel-footer"><a href="<?php echo e(route('indexCompras')); ?>">Entrar</a></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Ventas</div>
        <div class="panel-body"><img src="<?php echo e(asset('images/ventas.png')); ?>" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer"><a href="">Entrar</a></div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-primary">
        <div class="panel-heading">Almacen</div>
        <div class="panel-body"><img src="<?php echo e(asset('images/almacen.jpg')); ?>" class="img-responsive" style="width:90%" alt="Image"></div>
        <div class="panel-footer"><a href="<?php echo e(route('indexalmacen')); ?>">Entrar</a></div>  
      </div>
    </div>
  </div>
</div><br>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboardlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp\resources\views/dashboard.blade.php ENDPATH**/ ?>