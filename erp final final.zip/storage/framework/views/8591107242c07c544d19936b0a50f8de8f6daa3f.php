<?php $__env->startSection('content'); ?>
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Orden Pedido Proveedor </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="<?php echo e(route('nuevoPedido')); ?>" method="POST">
  <?php echo csrf_field(); ?>
 <div id="divform" name="divform">
  <div class="form-group">
      <label class="control-label">Cambiar estado de Pedido: </label> <select name="idpedestado" id="idpedestado" >
      <option value="">Selecciona el Nro</option>
      <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->id;?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
  </div>
       <br><br>
      <button type="submit" id="Bguarda" class="btn btn-primary">Nuevo Pedido</button>
      <button type="hidden" id="Benviar" class="btn btn-danger">Salir</button>
      <button type="button" id="Bvolver" class="btn btn-danger">Salir</button>
      <input type="hidden" id="valorj" name="valorj" value="0"/>
      <input type="hidden" id="canttotal" name="canttotal" value="0"/>
      <input type="hidden" id="idcompra" name="idcompra" value="0"/>
 </div>
 </form>
  <script src="/js/compras/OrdenCompra.js">
 </script>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Compras.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\base-erp\resources\views/Compras/Estadopedido.blade.php ENDPATH**/ ?>