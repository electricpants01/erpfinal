<?php $__env->startSection('content'); ?>
<style>
.seleccion {
  cursor: pointer;
}
.seleccion:hover{
  color: #0585C1;
}
</style>

<div class="container">
  <h2>Orden de Compra Proveedor </h2><br>
  <form name="pedidoprov" id="pedidoprov" action="<?php echo e(route('salirPedido')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
      <label class="control-label">Numero de Pedido :</label> <select name="idped" id="idped" >
      <option value="">Selecciona el Nro</option>
      <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->id;?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
     <label class="control-label"style="position:absolute;left: 55%;">Fecha :  <?php echo $fecha;?></label>
    </div>
    <table class="table table-striped" id="table-pedido">
        <thead>
        <tr>
        <th></th>
           <th>Producto</th>
           <th>Cantidad</th>
            <th>Precio</th>
            <th>Total</th>
            <th>Fecha expiracion</th>
            <th>Cantidad Actual</th>
        </tr>
        </thead>
        <tbody id="tdprod" values="">
         
         
        </tbody>
    </table><br><br>


    <div  class="form-group" style="position:absolute;left: 55%;">
    <label class="control-label">TOTAL A PAGAR :  </label><input style="position:absolute;left: 150%;" name="sumatotal" id="sumatotal" type="text" value="0" readonly="readonly" >
    </div><br><br>
    <button type="button" id="Bguardar" class="btn btn-primary">Guardar</button>
    <button type="button" id="Benviar" class="btn btn-defaul">Enviar</button>
    <button type="submit" id="Bsalir" class="btn btn-danger">Salir</button>
    <input type="hidden" id="valorj" name="valorj" value="0"/>
     <input type="hidden" id="canttotal" name="canttotal" value="0"/>
     <input type="hidden" id="idpedido" name="idpedido" value="0"/>

  
 </div>
 </form>
 <script src="/js/compras/ordenCompra.js">
 </script>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Compras.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/Compras/ordenCompra.blade.php ENDPATH**/ ?>