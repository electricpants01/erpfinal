<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('css/dashboard/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('css/dashboard/bootstrap.js')); ?>"></script>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
</head>
<body style="background-color:<?php echo e($color); ?>; font-family:<?php echo e($letra); ?>;">

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo e(route('super')); ?>">Super ERP</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li class="active"><a href="<?php echo e(route('carrito')); ?>">Carrito</a></li>
        <li><a href="#"></a></li>
			            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Colores <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="<?php echo e(route('color',['white'])); ?>">Blanco</a></li>
                      <li><a href="<?php echo e(route('color',['black'])); ?>">Negro</a></li>
                      <li><a href="<?php echo e(route('color',['orange'])); ?>">Naranja</a></li>
                      <li><a href="<?php echo e(route('color',['yellow'])); ?>">Amarillo</a></li>
                      <li><a href="<?php echo e(route('color',['green'])); ?>">Verde</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Fuentes de Letras <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="<?php echo e(route('letra',['serif'])); ?>">Serif</a></li>
                      <li><a href="<?php echo e(route('letra',['cursive'])); ?>">Cursiva</a></li>
                      <li><a href="<?php echo e(route('letra',['arial'])); ?>">Arial</a></li>
                      <li><a href="<?php echo e(route('letra',['system-ui'])); ?>">system-ui</a></li>
                      
                    </ul>
                  </li>
        <li class="active"><form action="<?php echo e(route('logout')); ?>" method="POST"><button type="submit" class="btn btn-success"> <?php echo csrf_field(); ?> Log out</button></form></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <form class="form-inline ">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/user/superlayout.blade.php ENDPATH**/ ?>