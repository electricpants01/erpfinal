<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('css/dashboard/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('css/dashboard/bootstrap.js')); ?>"></script>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
</head>
<body>


<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
    <h1>Compra Exitosa :)</h1>
    <img src="https://i.postimg.cc/gjW4GvLP/exitosa.png" class="img-thumbnail" alt="Cinque Terre" width="1000" height="500"> 

    <h1>Ver Factura Electronica aqui:</h1>
    <a href="<?php echo e(route('factura',[$usuario,$venta])); ?>">Ver Factura</a>
      <hr>
    </div>
    <div class="col-sm-2 sidenav">
     
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>Muy pronto en PlayStore</p>
</footer>

</body>
</html><?php /**PATH /var/app/current/resources/views/mail/compraexitosa.blade.php ENDPATH**/ ?>