

<?php $__env->startSection('content'); ?>
<div class="row content">
    <div class="col-sm-2 sidenav">
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>Empieza a beber!</h1>
      <table class="table table-striped">
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <h2><?php echo e($product->nombre); ?></h2> <br>
                    <?php echo e($product->descripcion); ?> <br>
                    <img src="<?php echo e(asset($product->imagen)); ?>" class="img-thumbnail" alt="<?php echo e($product->nombre); ?>" width="304" height="236"> <br>
                    Precio :  <?php echo e($product->costo_actual); ?>$
                    <a href="<?php echo e(route('adicionarcarrito',[$product->almacen_id,$product->producto_id])); ?>" class="btn btn-success" role="button">Añadir al Carrito</a>
                </td>
            </tr>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
  </table>
    <?php echo e($products->links()); ?>

    </div>
    <div class="col-sm-2 sidenav">
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.superlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/app/current/resources/views/user/super.blade.php ENDPATH**/ ?>