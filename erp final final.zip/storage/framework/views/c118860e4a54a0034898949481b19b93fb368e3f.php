<?php $__env->startSection('content'); ?>
    <div class="form-body">
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items"> 
                        <div class="website-logo-inside">
                          
                        </div>
                        <h3>Logeate Admin</h3>
                        <p>Entrar al panel administrativo</p>
                        <div class="page-links">
                        <a href="<?php echo e(route('login')); ?>" class="active">Entrar</a>
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input class="form-control" type="email" name="email" placeholder="Tu correo electronico" required="">
                            <input class="form-control" type="password" name="password" placeholder="Password" required="">
                            {<?php echo $errors->first('email','<span style="color:white">Revisa bien tu correo o contraseña</span>'); ?>}
                            <div class="form-button">
                                <button id="submit" type="submit" class="ibtn">Entrar ya!</button> 
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.loginlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\erpz\resources\views/auth/login.blade.php ENDPATH**/ ?>