<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('css/dashboard/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('css/dashboard/bootstrap.js')); ?>"></script>

</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\erpz\resources\views/layout.blade.php ENDPATH**/ ?>