


<?php $__env->startSection('content'); ?>


<div class="container">
  <h2>Crear Nuevo Almacen</h2><br>
  <form action="<?php echo e(route('crearalmacen')); ?>" method="POST">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <label >Direccion:</label>
      <input type="text" class="form-control" placeholder="La direccion del almacen" name="direccion">
    </div>
    <div class="form-group">
      <label >Telefono:</label>
      <input type="text" class="form-control" placeholder="Telefono de referencia" name="telefono">
    </div>
  
    <button type="submit" class="btn btn-default">Crear</button>
  </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/app/current/resources/views/almacen/almacenform.blade.php ENDPATH**/ ?>