

<?php $__env->startSection('content'); ?>
<div class="form-body">
        <div class="row">
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <div class="website-logo-inside">
                        </div>
                        <h3>Formulario de Registro</h3>
                        <p>Bienvenido a Super ERP</p>
                        <div class="page-links">
                            <a href="<?php echo e(route('login')); ?>">Entrar</a>
							<a href="<?php echo e(route('register')); ?>" class="active">Registrate</a>
                        </div>
                        <form method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input class="form-control" type="text" name="name" placeholder="Nombre Completo" required="">
                            <input class="form-control" type="email" name="email" placeholder="Correo Electronico" required="">
                            <input class="form-control" type="password" name="password" placeholder="Contraseña" required="">
                            <input class="form-control" type="password" name="password" placeholder="Confirmacion de la contraseña" required="">
                            {<?php echo $errors->first('password','<span style="color:white;">Revisa bien tu contraseña, min 6 caracteres</span>'); ?>}
                            {<?php echo $errors->first('email','<span style="color:white;">Usuario ya registrado anteriormente 
                            </span> <a href="#">Entrar</a>'); ?>}
                            <div class="form-button">
                                <button id="submit" type="submit" class="ibtn">Restrate ya!</button>
                            </div>
                        </form>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.loginlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/app/current/resources/views/user/register.blade.php ENDPATH**/ ?>