<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('test')); ?>" method="POST" >
 <?php echo csrf_field(); ?>
  nombre <input type="text" name="nombre"><br>
  fecha <input type="date" name="fecha"><br>
  edad <input type="text" name="edad"><br>
  <select  name="ciudad">
  <option value="">Su Ciudad</option>
  <option value="SC">Santa Cruz</option>
  <option value="CBB">Cocha</option>
  </select>
  <input type="submit" value="enviar">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\erpz\resources\views/test.blade.php ENDPATH**/ ?>