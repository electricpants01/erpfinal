<?php $__env->startSection('content'); ?>



<table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha expiracion</th>
            <th>Dias antes de expiracion</th>
            <th>Cantidad</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->id); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->costo_actual); ?></td>
                    <td><?php echo e($producto->fecha_expiracion); ?></td>
                    <td><?php echo e($producto->dias); ?></td>
                    <td><?php echo e($producto->cant_pedido); ?></td>
                </tr>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp\resources\views/almacen/devolucion.blade.php ENDPATH**/ ?>