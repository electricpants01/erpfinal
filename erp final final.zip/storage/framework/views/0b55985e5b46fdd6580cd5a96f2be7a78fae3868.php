<!DOCTYPE html>
<html lang="en">
<head>
  <title>Super ERP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/bootstrap.min.css')); ?>">
  <script src="<?php echo e(asset('css/dashboard/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('css/dashboard/bootstrap.js')); ?>"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  
<style>

.panel-placeholder {
  background-color: rgb(66, 139, 202);
  border-style: solid 1px;
  border-color: red;
  border-radius: 4px;
  margin-bottom: 18px;
  opacity: .5;

}

.new-campaign {
  list-style-type: none;
  padding: 5px;
  background-color: rgb(211,211,211);
  border-radius: 4px;
  min-height: 200px;
}

.current-campaign, .past-campaigns, .archive {
  list-style-type: none;
  padding: 5px;
  border-color: rgb(221,221,221);
  border-radius: 0px 0px 4px 4px;
  min-height: 200px;
}

.cancel {
  padding-left: 5px;
  display: none;
}

</style>

<style>
#menubi * { list-style:none;}
#menubi li{ line-height:180%;}
#menubi { padding:5%;}

#menubi li a{color:#222; text-decoration:none;}
#menubi li a:before{ content:"\025b8"; color:#ddd; margin-right:4px;}
#menubi input[name="list"] {
	position: absolute;
	left: -1000em;
	}
#menubi label:before{ content:"\025b8"; margin-right:4px;}
#menubi input:checked ~ label:before{ content:"\025be";}
#menubi .interior{display: none;}
#menubi input:checked ~ ul{display:block;}
.interior{padding-left:5%; padding-top:-5%;}
.labeln{margin:0px;}
</style>

</head>
</head>
<body id="body"style="background-color:#BDBDBD;">


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Super ERP </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo e(route('dashboard')); ?>">Inicio</a></li>
      <li><a class="dropdown-toggle" data-toggle="dropdown" href="#">Reportes</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Graficos </a></li>

      <li><a class="dropdown-toggle" data-toggle="dropdown" href="<?php echo e(route('restBI')); ?>">Restablecer</a></li>

    </ul>
  </div>
</nav>

<label for="">Seleccion una opcion :</label>
<select name="idcubo" id="idcubo">
    <option value="">Seleccione uno </option>
    <option value="1">Compras</option>
    <option value="2">Ventas</option>
    <option value="3">Almacen</option>
        
</select><br><br>
  <!--DISPLAY WORKSPACE --     
<ul id="menubi">
                           <li><input type="checkbox" name="list" id="nivel1-1"><label for="nivel1-1">Nivel 1</label>
                              <ul class="interior">
                               <li id="n1" name="Cnombre"><a href="#r">Nivel 2</a></li>
                              </ul>
                        </li>
                          <li><input type="checkbox" name="list" id="nivel2-1"><label for="nivel1-1">Nivel 2</li>
                         </ul>


<div id="nombre">
              <div class="prov">
              
              </div>  
            </div>

-DISPLAY WORKSPACE -->

<div class='row' id="workspace">
  <div class='col-lg-2 col-md-2 col-sm-2'>
     <ul id="ulbody" class="current-campaign panel">


          <li id="cliente" ><ul id="menubi">
                  <li><input type="checkbox" name="list" id="nivel1-1"><label id="labeln" for="nivel1-1">Cliente</label>
                     <ul class="interior">

                               <li  id="cliente" class="draggable" >
                                <div id="nombre"><div class="prov">
                                   <label for="">Nombre</label>
                                       <input type="hidden" id="tabla1" class="valores" name="tabla1" value="mesage"/>
                                       <input type="hidden" id="atributo1" class="valores" name="atributo1" value="message"/>
                                   </div></div></li>



                                <li  id="cliente" class="draggable" >
                                <div id="sexo"><div class="prov">
                                   <label for="">Sexo</label>
                                       <input type="hidden" id="clienten" class="valores" name="idpedido" value="message"/>
                                   </div></div></li>

                     </ul></li>
            </ul></li>




          <li id="cliente" class="draggable">
            <div id="sexo">
              <div class="prov">
                <label for="">Sexo</label>
                <input type="hidden" id="clienten" class="valores" name="idpedido" value="message"/>
              </div>  
            </div>
          </li>

          <li id="cliente" class="draggable">
            <div id="direccion">
              <div class="prov">
                <label for="">Direccion</label>
                <input type="hidden" id="clienten" class="valores" name="idpedido" value="message"/>
              </div>  
            </div>
          </li>


          </ul>
      </div>
  </div>
  <div class='row' id="workspace">
    <div id='new_campaign_workspace' class='col-lg-2 col-md-2 col-sm-2'>
    <label for="">Filas</label> 
      <ul class="new-campaign well"></ul>
     </div>
   <div id='new_campaign_workspace' class='col-lg-2 col-md-2 col-sm-2'>
   <label for="">Columnas</label> 
      <ul class="new-campaign well"></ul>
    </div>
  </div>

  <div class='row' id="workspace">
  <div id='new_campaign_workspace' class='col-lg-2 col-md-2 col-sm-2'>
  <label for="">Busqueda</label> 
    <ul class="new-campaign well"></ul>
</div>
<div id='new_campaign_workspace' class='col-lg-2 col-md-2 col-sm-2'>
<label for="">Filtros</label> 
    <ul class="new-campaign well"></ul>
</div>
</div>




      </div>


    </div>





<script src="/js/BI/prueba.js">
 </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/BI/prueba.blade.php ENDPATH**/ ?>