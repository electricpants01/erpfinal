<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/dashboard/bootstrap.min.css">
  <script src="css/dashboard/jquery.js"></script>
  <script src="css/dashboard/bootstrap.js"></script>
    <title>Factura</title>
</head>
<body>
<img src="erp.png" height="100" width="100">
<strong><h1 >Factura Electronica</h1></strong>

<h2>Folio Fiscal :</h2>
<h3>59EFREFERG-GERGE-RGHRT-JHTH-TERER</h3>
<h2>Certificado SIN : </h2>
<h3>20000000000000123545</h3>
<h2>Fecha : <?php echo now(); ?></h2> 


<h2>Receptor : <?php echo $persona[0]->name; ?></h2>
<h2>ID del usuario : <?php echo $persona[0]->id; ?></h2>
<table class="table table-striped">
        <thead>
        <tr>
            <th>Nombre</th>
            <th>Cantidad</th>
            <th>Precio</th>
            <th>Monto</th>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach($productos as $producto){
            echo "<tr>";
                echo "<td>".$producto->nombre."</td>";
                echo "<td>".$producto->cantidad."</td>";
                echo "<td>".$producto->precio."</td>";
                echo "<td>".$producto->cantidad*$producto->precio."</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
    <h2>Subtotal : <?php echo $sum[0]->sum; ?></h2>
    <h2>Subtotal + IVA (13 %) : <?php echo round($sum[0]->sum*1.13,2); ?></h2>
</body>
</html><?php /**PATH /var/app/current/resources/views/factura/factura.blade.php ENDPATH**/ ?>