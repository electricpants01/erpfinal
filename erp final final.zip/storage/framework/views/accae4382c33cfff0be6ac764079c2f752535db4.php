<?php $__env->startSection('content'); ?>



<div class="container">
  <h2>Modificar datos de Proovedor </h2><br>
  <form action="<?php echo e(route('seleccionproveedor')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
      <label >Proveedor:</label> <select name="idprov" >
      <option value="">Selecciona el Proveedor</option>
      <?php $__currentLoopData = $proveedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
            <option value="<?php echo $opcion->id;?>"><?php echo $opcion->nombre;?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <button type="submit" class="btn btn-default">buscar</button>
  </form>
</div>
<?php
//$gg=$_POST('idprov');
var_dump ($_POST);
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Compras.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp\resources\views/Compras/ModificarProveedor.blade.php ENDPATH**/ ?>