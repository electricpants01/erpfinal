<?php $__env->startSection('content'); ?>

    <table class="table table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Fecha pedido</th>
            <th>Cantidad</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->id); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td><?php echo e($producto->costo_actual); ?></td>
                    <td><?php echo e($producto->fecha_ultimo_pedido); ?></td>
                    <td><?php echo e($producto->cant_pedido); ?></td>
                </tr>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <h1>Cantidad de productos : <?php echo e($cant->cant); ?></h1>
    <h1>Actvo de la Empresa  : <?php echo e($activo->activo); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('almacen.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\base-erp2\resources\views/almacen/ALproducto.blade.php ENDPATH**/ ?>