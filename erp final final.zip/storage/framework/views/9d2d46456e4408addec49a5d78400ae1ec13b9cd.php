<?php $__env->startSection('content'); ?>

<div class="container">
  <h2>prueba </h2><br>
  <form action="<?php echo e(route('seleccionproveedor')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
      <label >Proveedor:</label>
    </div>
    <button type="submit" class="btn btn-default">buscar</button>
  </form>
</div>
<?php 
echo $id;
echo $estado;
echo $ids;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Compras.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\erpz\resources\views/Compras/prueba.blade.php ENDPATH**/ ?>