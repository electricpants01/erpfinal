<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetalleInventarioFisicosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_inventario_fisicos', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('cant_fisica');
            $table->integer('cant_logica');
            $table->decimal('costop',12,2);
            $table->decimal('precio',12,2);

            $table->unsignedBigInteger('inventario_fisico_id');
            $table->foreign('inventario_fisico_id')->references('id')->on('inventario_fisicos');
            $table->unsignedBigInteger('producto_id');
            $table->foreign('producto_id')->references('id')->on('productos');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detalle_inventario_fisicos');
    }
}
