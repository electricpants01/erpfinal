<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detalle_ventas extends Model
{
    //
}
