<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class BIController extends Controller
{
    

    public function  index(){
        return view('BI.prueba');
    }

    public function  rest(){
        return view('BI.prueba');
        echo("hola");
    }

      public function  cubo($id){

        if($id==1){  //cubos de compras
          $proveedor = BD::SELECT('SELECT * from proveedors');
          
        }
        if($id==2){ //cubos de ventas

        }
        if($id==3){ //cubos de almacen

        }
        
        return view('BI.prueba');
        echo("hola");
    }


}