<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use PDF;

class VentasController extends Controller
{
    


    public function index(){
        return view('ventas.index');
    }

    function reporte(){
        return view('ventas.reporte');
    }

    function reportehtml(){
        return view('ventas.reportehtml');
    }

    function creareporte(Request $request){
        $tablas = $request->input('tablas');
        $facturacols = $request->input('facturacols');
        if( $facturacols != NULL) $fcont = count($facturacols);
        else $fcont = 0;
        // ventas
        $ventacols = $request->input('ventacols');
        if($ventacols != NULL) $vcont = count($ventacols);
        else $vcont = 0;
        //detalle ventas
        $detallecols = $request->input('detalle_ventascols');
        if( $detallecols != NULL) $dt_cont = count($detallecols);
        else $dt_cont = 0;
        $sql = "select ";
        foreach($tablas as $tabla){
            if( $tabla == "facturas" and $fcont > 0 ){
                for( $i = 0 ; $i < $fcont; $i++ ){
                    if( $i == $fcont-1 and count($tablas) == 1) $sql .= $tabla.".".$facturacols[$i]." ";
                    else $sql .= $tabla.".".$facturacols[$i]." , ";
                }
            }
            if( $tabla == "ventas" and $vcont > 0 ){
                for( $i = 0 ; $i < $vcont; $i++ ){
                    if( $i == $vcont-1 and count($tablas) == 2) $sql .= $tabla.".".$ventacols[$i]." ";
                    else $sql .= $tabla.".".$ventacols[$i]." , ";
                }
            }
            if( $tabla == "detalle_ventas" and $dt_cont > 0 ){
                for( $i = 0 ; $i < $dt_cont; $i++ ){
                    if( $i == $dt_cont-1 and count($tablas) == 3) $sql .= $tabla.".".$detallecols[$i]." ";
                    else $sql .= $tabla.".".$detallecols[$i]." , ";
                }
            }
        }
        $sql .= "from facturas , ventas , detalle_ventas where facturas.id = ventas.factura_id and ventas.id = detalle_ventas.venta_id ";
        $fact_monto1 = $request->input('fact_monto1');
        $fact_monto2 = $request->input('fact_monto2');
        if( $fact_monto1 != NULL and $fact_monto2 != NULL){
            $sql .= "and facturas.monto between ".$fact_monto1." and ".$fact_monto2." ";            
        }
        $fact_montoneto1 = $request->input('fact_montoneto1');
        $fact_montoneto2 = $request->input('fact_montoneto2');
        if( $fact_montoneto1 != NULL and $fact_montoneto2 != NULL){
            $sql .= " and facturas.monto_neto between ".$fact_montoneto1." and ".$fact_montoneto2." ";
        }
        $fact_fecha = $request->input('fact_fecha');
        if( $fact_fecha != NULL){
            $sql .= "and facturas.fecha = '".$fact_fecha."' ";
        }
        $venta_cantidad1 = $request->input('venta_cantidad1');
        $venta_cantidad2 = $request->input('venta_cantidad2');
        if( $venta_cantidad1 != NULL and $venta_cantidad2 != NULL){
            $sql .= "and ventas.cantidad between ".$venta_cantidad1." and ".$venta_cantidad2." ";
        }
        $venta_monto1 = $request->input('venta_monto1');
        $venta_monto2 = $request->input('venta_monto2');
        if( $venta_monto1 != NULL and $venta_monto2 != NULL){
            $sql .= "and ventas.monto between ".$venta_monto1." and ".$venta_monto2." ";
        }
        $venta_fecha = $request->input('venta_fecha');
        if($venta_fecha != NULL){
            $sql .= "and ventas.fecha = '".$venta_fecha."' ";
        }
        $det_precio1 = $request->input('det_precio1');
        $det_precio2 = $request->input('det_precio2');
        if( $det_precio1 != NULL and $det_precio2 != NULL){
            $sql .= "and detalle_ventas.precio between ".$det_precio1." and ".$det_precio2." ";
        }
        
        $valores = DB::select($sql);
        $pdf = PDF::loadView('ventas.pdf',[
            'valores' => $valores, 
            'facturacols' => $facturacols,
            'ventacols' => $ventacols,
            'detallecols' => $detallecols
            ]);
        return $pdf->stream();

    }

    // crear reporte html
    function creareportehtml(Request $request){
        $tablas = $request->input('tablas');
        $facturacols = $request->input('facturacols');
        if( $facturacols != NULL) $fcont = count($facturacols);
        else $fcont = 0;
        // ventas
        $ventacols = $request->input('ventacols');
        if($ventacols != NULL) $vcont = count($ventacols);
        else $vcont = 0;
        //detalle ventas
        $detallecols = $request->input('detalle_ventascols');
        if( $detallecols != NULL) $dt_cont = count($detallecols);
        else $dt_cont = 0;
        $sql = "select ";
        foreach($tablas as $tabla){
            if( $tabla == "facturas" and $fcont > 0 ){
                for( $i = 0 ; $i < $fcont; $i++ ){
                    if( $i == $fcont-1 and count($tablas) == 1) $sql .= $tabla.".".$facturacols[$i]." ";
                    else $sql .= $tabla.".".$facturacols[$i]." , ";
                }
            }
            if( $tabla == "ventas" and $vcont > 0 ){
                for( $i = 0 ; $i < $vcont; $i++ ){
                    if( $i == $vcont-1 and count($tablas) == 2) $sql .= $tabla.".".$ventacols[$i]." ";
                    else $sql .= $tabla.".".$ventacols[$i]." , ";
                }
            }
            if( $tabla == "detalle_ventas" and $dt_cont > 0 ){
                for( $i = 0 ; $i < $dt_cont; $i++ ){
                    if( $i == $dt_cont-1 and count($tablas) == 3) $sql .= $tabla.".".$detallecols[$i]." ";
                    else $sql .= $tabla.".".$detallecols[$i]." , ";
                }
            }
        }
        $sql .= "from facturas , ventas , detalle_ventas where facturas.id = ventas.factura_id and ventas.id = detalle_ventas.venta_id ";
        $fact_monto1 = $request->input('fact_monto1');
        $fact_monto2 = $request->input('fact_monto2');
        if( $fact_monto1 != NULL and $fact_monto2 != NULL){
            $sql .= "and facturas.monto between ".$fact_monto1." and ".$fact_monto2." ";            
        }
        $fact_montoneto1 = $request->input('fact_montoneto1');
        $fact_montoneto2 = $request->input('fact_montoneto2');
        if( $fact_montoneto1 != NULL and $fact_montoneto2 != NULL){
            $sql .= " and facturas.monto_neto between ".$fact_montoneto1." and ".$fact_montoneto2." ";
        }
        $fact_fecha = $request->input('fact_fecha');
        if( $fact_fecha != NULL){
            $sql .= "and facturas.fecha = '".$fact_fecha."' ";
        }
        $venta_cantidad1 = $request->input('venta_cantidad1');
        $venta_cantidad2 = $request->input('venta_cantidad2');
        if( $venta_cantidad1 != NULL and $venta_cantidad2 != NULL){
            $sql .= "and ventas.cantidad between ".$venta_cantidad1." and ".$venta_cantidad2." ";
        }
        $venta_monto1 = $request->input('venta_monto1');
        $venta_monto2 = $request->input('venta_monto2');
        if( $venta_monto1 != NULL and $venta_monto2 != NULL){
            $sql .= "and ventas.monto between ".$venta_monto1." and ".$venta_monto2." ";
        }
        $venta_fecha = $request->input('venta_fecha');
        if($venta_fecha != NULL){
            $sql .= "and ventas.fecha = '".$venta_fecha."' ";
        }
        $det_precio1 = $request->input('det_precio1');
        $det_precio2 = $request->input('det_precio2');
        if( $det_precio1 != NULL and $det_precio2 != NULL){
            $sql .= "and detalle_ventas.precio between ".$det_precio1." and ".$det_precio2." ";
        }
        
        $valores = DB::select($sql);
        return view('ventas.reportehtml2')->with([
            'valores' => $valores, 
            'facturacols' => $facturacols,
            'ventacols' => $ventacols,
            'detallecols' => $detallecols
        ]);

    }
}
