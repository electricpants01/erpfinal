<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class comprasController extends Controller
{
    
    public function  index(){
        return view('Compras.Index');
    }
   
    public function redirectindex(){
        return redirect()->route('indexCompras');
    }
    function ModificarProveedor(){
        $proveedor = DB::select('select * from proveedors ');
        $id = DB::select('select id from proveedors ');
        $activo = collect(DB::select('select nombre as activo from proveedors'));
        $activo = $activo->toArray();
        $activo = $activo[0];
        if($activo->activo == null) $activo->activo = 0;
        return view('Compras.ModificarProveedor')->with([
            'proveedor' => $proveedor,
            'id' => $id,
            'activo' => $activo
        ]);  
    }
    function SeleccionarProveedor(){ 
        $id = request()->input('idprov');
        $proveedor = DB::select('select * from proveedors where id= ? ',[$id]);
        return view('Compras.modificarProv')->with([
            'proveedor' => $proveedor,
            'id' => $id,
        ]);
    }
    function AddProveedor(){
        return view('Compras.proveedorform',[
            ]);
    }

    function AddProveedors(){
        $nombre = request()->input('nombre');
        $nit = request()->input('nit');
        $tipo = request()->input('tipo');
        $direccion = request()->input('direccion');
        $email = request()->input('email');
        $telefono = request()->input('telefono');
        $estado = request()->input('estado');
        DB::insert('insert into proveedors(nit,nombre,direccion,email,telefono,tipo,estado) 
        values (?,?,?,?,?,?,?)',[
            $nit,$nombre,$direccion,$email,$telefono,$tipo,$estado
        ]);
        return redirect()->route('indexCompras');
    }

    function GuardarProveedors(){
        $id=request()->input('id');
        $nombre = request()->input('nombre');
        $nit = request()->input('nit');
        $tipo = request()->input('tipo');
        $direccion = request()->input('direccion');
        $email = request()->input('email');
        $telefono = request()->input('telefono');
        $estado = request()->input('estado');
        DB::insert('UPDATE proveedors set nit= ?,nombre= ?,direccion= ?,email= ?,telefono= ?,tipo= ?,estado= ? where id= ?',
        [
            $nit,$nombre,$direccion,$email,$telefono,$tipo,$estado,$id
        ]);
        return redirect()->route('indexCompras');
    }

    function EliminarProveedors(){
        $id=request()->input('id');
        DB::insert('DELETE proveedors  where id= ?',
        [
           $id
        ]);
        return redirect()->route('indexCompras');
    }


   /////////controladores para pedido proveedor 
 
   function   nuevoPedido(){
   // header('Location: indexCompras');
    return redirect()->route('PedidoProveedor');
   }
   function  estadoPedido(){
    // header('Location: indexCompras');
    $estadonuevo = request()->input('idpedestado');
    $idped = request()->input('idestadoped'); 
   DB::insert('UPDATE pedidos set estado= ? where id= ?',[$estadonuevo,$idped]);
     return  $idped;
    }
    
   function PedidoProv(){
        $proveedor = DB::select('select * from proveedors ');
        $producto = DB::select('select * from productos ');      
        $id = DB::select('select id from proveedors ');
        $fecha = date('Y-m-d'); 
        return view('Compras.pedidoprov')->with([
            'proveedor' => $proveedor,
            'id' => $id,
            'producto'=>$producto,
            'fecha'=>$fecha
        ]);
    
    }

    function AgregarPedidoProv(){
        $idprov = request()->input('iddprov');
        $j = request()->input('valorj'); 
        $fecha = date('Y-m-d'); 
        $sumtotal = request()->input('sumatotal');
        $cantotal = request()->input('canttotal'); 
        $idempleado = 1;
        $estadoped = 3; //1=aceptado 2=no aceptado 3=pendiente 4=guardado en compra
    DB::insert('INSERT into pedidos(cantidad,monto_pedido,fecha,empleado_id,proveedor_id,estado) 
        values (?,?,?,?,?,?)',[
          $cantotal,$sumtotal,$fecha,$idempleado,$idprov,$estadoped
            ]);
       $idpedido = DB::select('SELECT * from pedidos order by id desc limit 1');
     for($i=0;$i<=$j;$i++){
        $tdnombre = "tdnombre".$i;
        $prodnombre = request()->input($tdnombre); 
        if($prodnombre){
            $imnro ="imnro".$i;
            $itdprecio ="itdprecio".$i;
            $itdtotal ="itdtotal".$i;
            $idproducto[] = request()->input($tdnombre);
            $cantidad[] =request()->input($imnro);
           $precio[] =request()->input($itdprecio);
            $total[] =request()->input($itdtotal);
            }
      }
    
  for($k=0;$k<sizeof($idproducto);$k++){
    DB::insert('INSERT into detalle_pedidos(cantidad,precio,sub_total,pedido_id,producto_id) 
    values (?,?,?,?,?)',[
        $cantidad[$k],$precio[$k],$total[$k],$idpedido[0]->id,$idproducto[$k]
        ]);
  }
   return $idpedido[0]->id;
}

 function showproduct($id){
    $prod = DB::select('select * from productos where id= ? ',[$id]);
    return $prod;

  }
  function EstadoPedidoProv(){
      $estado= 3;

    $pedido = DB::select('select * from pedidos where estado= ? ',[$estado]);
      return view('Compras.Estadopedido')->with([
        'pedido' => $pedido,
        ]); 
  }
  //funcion que envia los datos del pedido
  function ultimopedido(){
    $idpedido = DB::select('SELECT * from pedidos order by id desc limit 1');
    $pedido = DB::select('SELECT * from pedidos where id = ?',[$idpedido[0]->id]);
    return $pedido;
  }
  function CompraProv(){
    $pedido = DB::select('SELECT * from pedidos where estado=1');
    $fecha = date('Y-m-d'); 
    return view('Compras.ordenCompra')->with([
        'pedido' => $pedido,
        'fecha' => $fecha
        
    ]);
 }
 ///funciones de orden de compra
 function showdetallepedido($id){
   // $idpedido = DB::select('SELECT * from detalle_pedidos order by id desc limit 1');
    //$dpedido = DB::select('SELECT * from detalle_pedidos,productos where pedido_id = ? and productos.id=?',[$id]);
    $dped = DB::select('SELECT detalle_pedidos.cantidad,detalle_pedidos.precio,detalle_pedidos.sub_total,productos.nombre,productos.id FROM productos,detalle_pedidos WHERE detalle_pedidos.pedido_id=? and productos.id=detalle_pedidos.producto_id',[$id]);
    
    return $dped;
  }

  function AgregarCompraProv(){
    $idpedido = request()->input('idpedido');
    $j = request()->input('valorj'); 
    $fecha = date('Y-m-d'); 
    $sumtotal = request()->input('sumatotal');
    $cantotal = request()->input('canttotal'); 
    $idproveedor = DB::select('SELECT pedidos.proveedor_id FROM pedidos WHERE pedidos.id=? ',[$idpedido]);
    $estadocompra=3;   //1=entregado 2=no entregado 3=pendiente 4=devolucion
    $estadopedido=4;   //1=entregado 2=no entregado 3=pendiente 4=copiado a compra
  DB::insert('INSERT into compras(cantidad,costo,fecha,proveedor_id,pedido_id,estado) 
    values (?,?,?,?,?,?)',[
      $cantotal,$sumtotal,$fecha,$idproveedor[0]->proveedor_id,$idpedido,$estadocompra
        ]);
    $idcompra = DB::select('SELECT * from compras order by id desc limit 1');
    DB::insert('UPDATE pedidos set estado= ? where id= ?',[$estadopedido,$idpedido]);
    
 for($i=0;$i<=$j;$i++){
    $tdnombre = "tdnombre".$i;
    $prodnombre = request()->input($tdnombre); 
    if($prodnombre){
        $imnro ="imnro".$i;
        $itdprecio ="itdprecio".$i;
        $itdtotal ="itdtotal".$i;
        $idproducto[] = request()->input($tdnombre);
        $cantidad[] =request()->input($imnro);
       $precio[] =request()->input($itdprecio);
        $total[] =request()->input($itdtotal);
        }
  }

  for($k=0;$k<sizeof($idproducto);$k++){
   DB::insert('INSERT into detalle_compras(cantidad,costo,costo_sub_total,compra_id,producto_id) 
   values (?,?,?,?,?)',[
    $cantidad[$k],$precio[$k],$total[$k],$idcompra[0]->id,$idproducto[$k]
    ]);
  }
  return "hola";//$idpedido[0]->id; 
  }
 //// controladores de ingreso de producto

 function IngresoProdProv(){
    $Compras = DB::select('SELECT * from Compras where estado = 3' );
    $fecha = date('Y-m-d'); 
    return view('Compras.IngresoProdProv')->with([
        'compras' => $Compras,
        'fecha' => $fecha
        
    ]);
 }

 function showdetallecompra($id){
    // $idpedido = DB::select('SELECT * from detalle_pedidos order by id desc limit 1');
     //$dpedido = DB::select('SELECT * from detalle_pedidos,productos where pedido_id = ? and productos.id=?',[$id]);
     $dcompra = DB::select('SELECT detalle_compras.cantidad,detalle_compras.costo,detalle_compras.costo_sub_total,productos.nombre,productos.id FROM productos,detalle_compras WHERE detalle_compras.compra_id=? and productos.id=detalle_compras.producto_id',[$id]);
     
     return $dcompra;
   }

   function AgregarIngresoProdProv(){
    $idcompra = request()->input('idcompra');
    $j = request()->input('valorj'); 
    $fecha = date('Y-m-d'); 
    $sumtotal = request()->input('sumatotal');
    $cantotal = request()->input('canttotal'); 
    $idproveedor = DB::select('SELECT compras.proveedor_id FROM compras WHERE compras.id=? ',[$idcompra]);
    $idalmacen=1;   //1=entregado 2=no entregado 3=pendiente
    $estadoAceptado=1;
  DB::insert('INSERT into nota_ingresos(cantidad,monto_ingreso,fecha,almacen_id,compra_id) 
    values (?,?,?,?,?)',[
      $cantotal,$sumtotal,$fecha,$idalmacen,$idcompra
        ]);
    $idingreso = DB::select('SELECT * from nota_ingresos order by id desc limit 1');
   DB::insert('UPDATE compras set estado= ? where id= ?',[$estadoAceptado,$idcompra]);//cambiamos el estado de la compra a aceptado
    
 for($i=0;$i<=$j;$i++){
    $tdnombre = "tdnombre".$i;
    $prodnombre = request()->input($tdnombre); 
    if($prodnombre){
        $imnro ="imnro".$i;
        $itdprecio ="itdprecio".$i;
        $itdtotal ="itdtotal".$i;
        $idproducto[] = request()->input($tdnombre);
        $cantidad[] =request()->input($imnro);
       $precio[] =request()->input($itdprecio);
        $total[] =request()->input($itdtotal);
        }
  }
  for($m=0;$m<sizeof($idproducto);$m++){
   DB::insert('INSERT into detalle_ingresos(cantidad,costop,submonto,ingreso_id,producto_id) 
   values (?,?,?,?,?)',[
    $cantidad[$m],$precio[$m],$total[$m],$idingreso[0]->id,$idproducto[$m]
    ]);

    $devolucion=0;
   $almacenprod= DB::select('SELECT * from almacen_productos where producto_id=?',[$idproducto[$m]]);
     if($almacenprod){
        $cant = $cantidad[$m] + $almacenprod[0]->cantidad;
        $monto = $total[$m] + $almacenprod[0]->costo_actual;
      DB::insert('UPDATE almacen_productos set cantidad= ?,costo_actual= ? where producto_id= ?',[$cant,$monto,$idproducto[$m]]);//cambiamos cantidad y monto de almacen-producto
     }else{
   DB::insert('INSERT into almacen_productos(cantidad,costo_actual,almacen_id,producto_id,devolucion) 
   values (?,?,?,?,?)',[
    $cantidad[$m],$total[$m],$idalmacen,$idproducto[$m],$devolucion
    ]);
     }

  }
  return $sumtotal;//$idpedido[0]->id; 
  }
//// funcione de devolucion

function AddDevolucion(){
  $Compras = DB::select('SELECT * from Compras where estado = 1' );
  $nombre =DB::select('SELECT nombre from proveedors where id = ?',[$Compras[0]->proveedor_id] );
  $fecha = date('Y-m-d'); 
  return view('Compras.Devolucion')->with([
      'compras' => $Compras,
      'fecha' => $fecha,
      'nombre'=> $nombre[0]->nombre
      
  ]);
}
function showdetalleproveedor($id){
  $idprov =  DB::select('SELECT proveedor_id  from Compras where id = ?',[$id] );
   //$dpedido = DB::select('SELECT * from detalle_pedidos,productos where pedido_id = ? and productos.id=?',[$id]);
   $dcompra = DB::select('SELECT nombre FROM proveedors WHERE id=?',[$idprov[0]->proveedor_id]);
   
   return $dcompra;
 }

 function AgregarDevolucion(){
  $idcompra = request()->input('idcompraval');
  $j = request()->input('valorj'); 
  $fecha = date('Y-m-d'); 
  $sumtotal = request()->input('sumatotal');
  $cantotal = request()->input('canttotal'); 
  $estadocompra=4;   //1=entregado 2=devuelto
  $idalmacen=1;   ///verificar que este almacen esta creado
  $estdevolucion=3 ;/// colocamos el estado como pendiente 1=renovado 2="" 3=pendiente
DB::insert('INSERT into nota_devolucions(cantidad,costo,fecha,compra_id,estado) 
  values (?,?,?,?,?)',[
    $cantotal,$sumtotal,$fecha,$idcompra,$estdevolucion
      ]);
  $iddevolucion = DB::select('SELECT * from nota_devolucions order by id desc limit 1');
 for($i=0;$i<=$j;$i++){
  $tdnombre = "tdnombre".$i;
  $prodnombre = request()->input($tdnombre); 
  if($prodnombre){
      $imnro ="imnro".$i;
      $itdprecio ="itdprecio".$i;
      $itdtotal ="itdtotal".$i;
      $idproducto[] = request()->input($tdnombre);
      $cantidad[] =request()->input($imnro);
     $precio[] =request()->input($itdprecio);
      $total[] =request()->input($itdtotal);
      }
}
for($k=0;$k<sizeof($idproducto);$k++){
 DB::insert('INSERT into detalle_devolucions(cantidad,costo,sub_total,devolucion_id,producto_id) 
 values (?,?,?,?,?)',[
  $cantidad[$k],$precio[$k],$total[$k],$iddevolucion[0]->id,$idproducto[$k]
  ]);

  $almacenprod= DB::select('SELECT * from almacen_productos where producto_id=?',[$idproducto[$k]]);
  $cant = $almacenprod[0]->cantidad - $cantidad[$k];
  $monto = $almacenprod[0]->costo_actual - $total[$k];
  $devuelto =$cantidad[$k] + $almacenprod[0]->devolucion;
DB::insert('UPDATE almacen_productos set cantidad= ?,costo_actual= ?,devolucion= ? where producto_id= ?',[$cant,$monto,$devuelto,$idproducto[$k]]);//cambiamos cantidad y monto de almacen-producto


}
DB::insert('UPDATE compras set estado= ? where id= ?',[$estadocompra,$idcompra]);
return "hola";//$idpedido[0]->id; 
}

////estado devolucion
function EstadoDevolucion(){
  $devolucion = DB::select('SELECT * from nota_devolucions where estado = 3' );
  //$devolucion =DB::select('SELECT * from nota_devolucions where compra_id = ?',[$Compras[0]->proveedor_id] );
  $fecha = date('Y-m-d'); 
  return view('Compras.estadoDevolucion')->with([
      'devolucion' => $devolucion,
      'fecha' => $fecha
     // 'nombre'=> $nombre[0]->nombre    
  ]);
}
function showdetalledevolucion($id){
  $dcompra = DB::select('SELECT detalle_devolucions.cantidad,detalle_devolucions.costo,detalle_devolucions.sub_total,productos.nombre,productos.id FROM productos,detalle_devolucions WHERE detalle_devolucions.devolucion_id=? and productos.id=detalle_devolucions.producto_id',[$id]);
     
  return $dcompra;
}
function AgregarEstadoDevolucion(){
  $iddev = request()->input('iddev');
  $j = request()->input('valorj'); 
  $fecha = date('Y-m-d'); 
  $sumtotal = request()->input('sumatotal');
  $cantotal = request()->input('canttotal'); 
  $estdevolucion = request()->input('iddevo'); 
  
  $estadocompra=1;   //1=entregado 2=devuelto
  $idalmacen=1;   ///verificar que este almacen esta creado
  //$estdevolucion=3 ;/// colocamos el estado como pendiente 1=renovado 2=rechazado 3=pendiente
/*DB::insert('INSERT into nota_devolucions(cantidad,costo,fecha,compra_id,estado) 
  values (?,?,?,?,?)',[
    $cantotal,$sumtotal,$fecha,$idcompra,$estdevolucion
      ]);*/
 $idcompra = DB::select('SELECT compra_id from nota_devolucions where id=?',[$iddev]);
DB::insert('UPDATE nota_devolucions set estado= ? where id= ?',[$estdevolucion,$iddev]);
 if($estdevolucion==1){
  for($i=0;$i<=$j;$i++){
    $tdnombre = "tdnombre".$i;
    $prodnombre = request()->input($tdnombre); 
     if($prodnombre){
      $imnro ="imnro".$i;
      $itdprecio ="itdprecio".$i;
      $itdtotal ="itdtotal".$i;
      $idproducto[] = request()->input($tdnombre);
      $cantidad[] =request()->input($imnro);
     $precio[] =request()->input($itdprecio);
      $total[] =request()->input($itdtotal);
      }
  }
  for($k=0;$k<sizeof($idproducto);$k++){
   /*DB::insert('INSERT into detalle_devolucions(cantidad,costo,sub_total,devolucion_id,producto_id) 
   values (?,?,?,?,?)',[
     $cantidad[$k],$precio[$k],$total[$k],$iddevolucion[0]->id,$idproducto[$k]
    ]);*/

    $almacenprod= DB::select('SELECT * from almacen_productos where producto_id=?',[$idproducto[$k]]);
    $cant = $almacenprod[0]->cantidad + $cantidad[$k];
    $monto = $almacenprod[0]->costo_actual + $total[$k];
    $devuelto = $almacenprod[0]->devolucion - $cantidad[$k];
  DB::insert('UPDATE almacen_productos set cantidad= ?,costo_actual= ?,devolucion= ? where producto_id= ?',[$cant,$monto,$devuelto,$idproducto[$k]]);//cambiamos cantidad y monto de almacen-producto

  }
}
DB::insert('UPDATE compras set estado= ? where id= ?',[$estadocompra,$idcompra[0]->compra_id]);

return "hola";//$idpedido[0]->id; 
}





  }

