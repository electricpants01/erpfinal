<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class AlmacenController extends Controller
{
    

    public function  index(){
        return view('almacen.index');
    }

    function showProducto(){
        $productos = DB::select('select * from productos');
        $cant = collect(DB::select('select count(*) as cant from productos'));
        $cant = $cant->toArray();
        $cant = $cant[0];
        $activo = collect(DB::select('select sum(cant_pedido * costo_actual) as activo from productos'));
        $activo = $activo->toArray();
        $activo = $activo[0];
        if($activo->activo == null) $activo->activo = 0;
        return view('almacen.ALproducto')->with([
            'productos' => $productos,
            'cant' => $cant,
            'activo' => $activo
        ]);
    }

    function productoForm(){
        $categorias = DB::select('select * from categorias order by nombre asc');
        $marcas = DB::select('select * from marcas order by nombre asc');
        return view('almacen.productoform',[
            'categorias' => $categorias,
            'marcas' => $marcas
            ]);
    }

    function crearProducto(){
        
        $nombre = request()->input('nombre');
        $costo = request()->input('costo');
        $cantidad = request()->input('cantidad');
        $inventario_min = request()->input('inventario_min');
        $fecha_expiracion = request()->input('fecha');
        $descripcion = request()->input('descripcion');
        $categoria = request()->input('categoria');
        $marca = request()->input('marca');
        $imagen = 'images/default.jpg';
        // ahora insertamos a la tabla Productos
        DB::insert('insert into productos(nombre,costo_actual,cant_pedido,inventario_min,fecha_expiracion,descripcion,
        categoria_id,marca_id,imagen) values (?,?,?,?,?,?,?,?,?)',[
            $nombre,$costo,$cantidad,$inventario_min,$fecha_expiracion,$descripcion,$categoria,$marca,$imagen
        ]);

        return redirect()->route('indexalmacen');
    }
    function showAlmacen(){
        $almacenes = DB::select('select * from almacens');
        return view('almacen.showalmacen')->with([
            'almacenes' => $almacenes
        ]);
    }

    function almacenForm(){
        return view('almacen.almacenform');
    }
    
    function crearAlmacen(){
        $direccion = request()->input('direccion');
        $telefono = request()->input('telefono');
        DB::insert('insert into almacens(direccion,telefono,valor_almacenado,cantidad,sucursal_id) values(?,?,?,?,?)',[$direccion, $telefono,0.0,0,1]);
        return redirect()->route('indexalmacen');
    }


    function marcaForm(){
        return view('almacen.marca');
    }
    function crearMarca(){
       $tabla = request()->input('tabla');
       $nombre = request()->input('nombre');
       if( $tabla == 1){ // se insertara en Marca
           $sql = collect(DB::select('select count(nombre) as cant from marcas where nombre = ?',[$nombre] ));
           $sql = $sql->toArray();
           $sql = $sql[0];
           if( $sql->cant == 0){
               DB::insert('insert into marcas(nombre) values(?)',[$nombre]);
           }
       }
       if( $tabla == 2) // se insertara en Categoria
       {
        $sql = collect(DB::select('select count(nombre) as cant from categorias where nombre = ?',[$nombre] ));
        $sql = $sql->toArray();
        $sql = $sql[0];
        if( $sql->cant == 0){
            DB::insert('insert into categorias(nombre) values(?)',[$nombre]);
        }
       }
       return redirect()->route('indexalmacen');
    }

    public function verDevolucion(){
        $productos = DB::select('select *,datediff(fecha_expiracion,now()) as dias from productos 
        where datediff(fecha_expiracion,now()) <= 20 order by datediff(fecha_expiracion,now()) asc');
        return view('almacen.devolucion',[
            'productos' => $productos
        ]);
    }

    public function verAbastecimiento(){
        $productos = DB::select('select * from productos where inventario_min > cant_pedido order by cant_pedido asc');
        return view('almacen.abastecimiento',[
            'productos' => $productos
        ]);
    }
    
}
