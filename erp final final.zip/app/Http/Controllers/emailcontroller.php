<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Mail;
use Sesion;
use Redirect;
use PDF;
use App;
class emailcontroller extends Controller
{
 
public function store(Request $request){

  Mail::send('reportes/vista',$request->all(), function($msj){
    $idpedido = DB::select('SELECT * from pedidos order by id desc limit 1');
   $pedido = DB::select('SELECT * from pedidos where id= ? ',[$idpedido[0]->id]);
    $detalleped = DB::select('SELECT * from detalle_pedidos where	pedido_id= ? ',[$idpedido[0]->id]);
    $proveedor = DB::select('SELECT * from proveedors where id= ? ',[ $pedido[0]->proveedor_id]);
 
  $fecha = date('Y-m-d'); 
  $html =   '<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Example 1</title>
      <link rel="stylesheet" href="css/reportes/style.css" media="all" />
    </head>
    <body>
    
    <?php
       $prueb= "haber si esta sale";
       ?>
      <header class="clearfix">
        <div id="logo">
          <img src="css/reportes/imagen/logo.png">
        </div>
        <h1>PEDIDO DE PRODUCTOS</h1>
        <div id="company" class="clearfix">
          <div>Nombre de la Empresa: </div>
          <div>Sistemas ERP,<br /> AZ 85004, US</div>
          <div>(602) 519-0450</div>
          <div><a href="mailto:company@example.com">sistemaerp2@gmail.com</a></div>
        </div>
        <div id="project">
          <div><span>Razon </span> Pedido nro '.$idpedido[0]->id.'</div>
          <div><span>Cliente</span>Sistemas ERP Comercial></div>
          <div><span>Direccion</span>SANTA CRUZ DE LA SIERRA</div>
          <div><span>E-mail</span> <a href="mailto:john@example.com">sistemaerp2@gmail.com</a></div>
          <div><span>Fecha</span>  '.$fecha.'</div>
         
        </div>
      </header>
      <main>
        <table>
          <thead>
            <tr>
              <th class="service">PRODUCTO</th>
              <th>PRECIO</th>
              <th>CANTIDAD</th>
              <th>TOTAL</th>
            </tr>
          </thead>
          <tbody id="tablareporte">';
 
          for($i=0;$i<sizeof($detalleped);$i++){
        $productos =  DB::select('SELECT nombre from productos where id= ? ',[ $detalleped[$i]->producto_id]);
         $html .= '<tr><td class="service">'.$productos[0]->nombre.'</td>';
         $html .= ' <td class="unit">$'.$detalleped[$i]->precio.'</td>'; 
         $html .= ' <td class="qty">'.$detalleped[$i]->cantidad.'</td>'; 
         $html .= ' <td class="total">$'.$detalleped[$i]->sub_total.'</td>'; 
         $html .= '</tr>';                
          }
          $html .= '    
            <tr>
              <td colspan="4">SUBTOTAL</td>
              <td class="total">$'.$idpedido[0]->monto_pedido.'</td>
            </tr>
           
            <tr>
              <td colspan="4" class="grand total">GRAN TOTAL</td>
              <td class="grand total">$'.$idpedido[0]->monto_pedido.'</td>
            </tr>
          </tbody>
        </table>
        <div id="notices">
          <div>NOTICE:</div>
          <div class="notice">A finance charge of 1.5% will be made on unpaid balances after 30 days.</div>
        </div>
      </main>
      <footer>
       nota depedido de productos al proveedor porfavor indicar lo mas pronto posible
      </footer>
    </body>
  </html>
  '
;

$pdf = App::make('dompdf.wrapper');

$pdf->loadHTML($html);
   //$pdf = PDF::loadView('reportes/vista');
  $msj->subject('Orden de Pedido');
  $msj->to('maldavich@gmail.com');
  $msj->attachData($pdf->output(), 'Pedido.pdf');
  
 });
return "Exitosamente";
}   //
public function storeCompra(Request $request){

  Mail::send('reportes/vista',$request->all(), function($msj){
    $idcompra = DB::select('SELECT * from Compras order by id desc limit 1');
   $compra = DB::select('SELECT * from Compras where id= ? ',[$idcompra[0]->id]);
    $detallecompra = DB::select('SELECT * from detalle_compras where	compra_id= ? ',[$idcompra[0]->id]);
    $proveedor = DB::select('SELECT * from proveedors where id= ? ',[ $compra[0]->proveedor_id]);
   $fecha = date('Y-m-d');

    $html =   '<!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <title>Example 1</title>
        <link rel="stylesheet" href="css/reportes/style.css" media="all" />
      </head>
      <body>
      
      <?php
         $prueb= "haber si esta sale";
         ?>
        <header class="clearfix">
          <div id="logo">
            <img src="css/reportes/imagen/logo.png">
          </div>
          <h1>COMPRA DE PRODUCTOS</h1>
          <div id="company" class="clearfix">
            <div>Nombre de la Empresa: </div>
            <div>Sistemas ERP,<br /> AZ 85004, US</div>
            <div>(602) 519-0450</div>
            <div><a href="mailto:company@example.com">sistemaerp2@gmail.com</a></div>
          </div>
          <div id="project">
            <div><span>Razon </span> Compra nro '.$idcompra[0]->id.'</div>
            <div><span>Cliente</span>Sistemas ERP Comercial></div>
            <div><span>Direccion</span>SANTA CRUZ DE LA SIERRA</div>
            <div><span>E-mail</span> <a href="mailto:john@example.com">sistemaerp2@gmail.com</a></div>
            <div><span>Fecha</span>  '.$fecha.'</div>       
          </div>
        </header>
        <main>
          <table>
            <thead>
              <tr>
                <th class="service">PRODUCTO</th>
                <th>PRECIO</th>
                <th>CANTIDAD</th>
                <th>TOTAL</th>
              </tr>
            </thead>
            <tbody id="tablareporte">';
   
            for($i=0;$i<sizeof($detallecompra);$i++){
          $productos =  DB::select('SELECT nombre from productos where id= ? ',[ $detallecompra[$i]->producto_id]);
           $html .= '<tr><td class="service">'.$productos[0]->nombre.'</td>';
           $html .= ' <td class="unit">$'.$detallecompra[$i]->costo.'</td>'; 
           $html .= ' <td class="qty">'.$detallecompra[$i]->cantidad.'</td>'; 
           $html .= ' <td class="total">$'.$detallecompra[$i]->costo_sub_total.'</td>'; 
           $html .= '</tr>';                
            }
            $html .= '    
              <tr>
                <td colspan="4">SUBTOTAL</td>
                <td class="total">$'.$idcompra[0]->costo.'</td>
              </tr>
             
              <tr>
                <td colspan="4" class="grand total">GRAN TOTAL</td>
                <td class="grand total">$'.$idcompra[0]->costo.'</td>
              </tr>
            </tbody>
          </table>
          <div id="notices">
            <div>NOTICE:</div>
            <div class="notice">A finance charge of 1.5% will be made on unpaid balances after 30 days.</div>
          </div>
        </main>
        <footer>
         nota depedido de productos al proveedor porfavor indicar lo mas pronto posible
        </footer>
      </body>
    </html>
    '
  ;
  



    
$pdf = App::make('dompdf.wrapper');

$pdf->loadHTML($html);
   //$pdf = PDF::loadView('reportes/vista');
  $msj->subject('Orden de Compra');
  $msj->to('maldavich@gmail.com');
  $msj->attachData($pdf->output(), 'Compra.pdf');
  
 });
return "Exitosamente";

  }

  public function storeDevolucion(Request $request){

    Mail::send('reportes/vista',$request->all(), function($msj){
      $iddevolucion = DB::select('SELECT * from nota_devolucions order by id desc limit 1');
     $devolucion = DB::select('SELECT * from nota_devolucions where id= ? ',[$iddevolucion[0]->id]);
      $detalledevolucion = DB::select('SELECT * from detalle_devolucions where	devolucion_id= ? ',[$iddevolucion[0]->id]);
  //$proveedor = DB::select('SELECT * from proveedors where id= ? ',[ $compra[0]->proveedor_id]);
     $fecha = date('Y-m-d');
      $html =   '<!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="utf-8">
          <title>Example 1</title>
          <link rel="stylesheet" href="css/reportes/style.css" media="all" />
        </head>
        <body>
        
        <?php
           $prueb= "haber si esta sale";
           ?>
          <header class="clearfix">
            <div id="logo">
              <img src="css/reportes/imagen/logo.png">
            </div>
            <h1>COMPRA DE PRODUCTOS</h1>
            <div id="company" class="clearfix">
              <div>Nombre de la Empresa: </div>
              <div>Sistemas ERP,<br /> AZ 85004, US</div>
              <div>(602) 519-0450</div>
              <div><a href="mailto:company@example.com">sistemaerp2@gmail.com</a></div>
            </div>
            <div id="project">
              <div><span>Razon </span> Devolucion nro '.$iddevolucion[0]->id.'</div>
              <div><span>Cliente</span>Sistemas ERP Comercial></div>
              <div><span>Direccion</span>SANTA CRUZ DE LA SIERRA</div>
              <div><span>E-mail</span> <a href="mailto:john@example.com">sistemaerp2@gmail.com</a></div>
              <div><span>Fecha</span>  '.$fecha.'</div>       
            </div>
          </header>
          <main>
            <table>
              <thead>
                <tr>
                  <th class="service">PRODUCTO</th>
                  <th>PRECIO</th>
                  <th>CANTIDAD</th>
                  <th>TOTAL</th>
                </tr>
              </thead>
              <tbody id="tablareporte">';
     
              for($i=0;$i<sizeof($detalledevolucion);$i++){
            $productos =  DB::select('SELECT nombre from productos where id= ? ',[ $detalledevolucion[$i]->producto_id]);
             $html .= '<tr><td class="service">'.$productos[0]->nombre.'</td>';
             $html .= ' <td class="unit">$'.$detalledevolucion[$i]->costo.'</td>'; 
             $html .= ' <td class="qty">'.$detalledevolucion[$i]->cantidad.'</td>'; 
             $html .= ' <td class="total">$'.$detalledevolucion[$i]->sub_total.'</td>'; 
             $html .= '</tr>';                
              }
              $html .= '    
                <tr>
                  <td colspan="4">SUBTOTAL</td>
                  <td class="total">$'.$iddevolucion[0]->costo.'</td>
                </tr>
               
                <tr>
                  <td colspan="4" class="grand total">GRAN TOTAL</td>
                  <td class="grand total">$'.$iddevolucion[0]->costo.'</td>
                </tr>
              </tbody>
            </table>
            <div id="notices">
              <div>NOTICE:</div>
              <div class="notice">A finance charge of 1.5% will be made on unpaid balances after 30 days.</div>
            </div>
          </main>
          <footer>
           nota depedido de productos al proveedor porfavor indicar lo mas pronto posible
          </footer>
        </body>
      </html>
      '
    ;
  $pdf = App::make('dompdf.wrapper');
  
  $pdf->loadHTML($html);
     //$pdf = PDF::loadView('reportes/vista');
    $msj->subject('Devolucion de Productos');
    $msj->to('maldavich@gmail.com');
    $msj->attachData($pdf->output(), 'Devolucion.pdf');
    
   });
  return "Exitosamente";
  
    }
  











}