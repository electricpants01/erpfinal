<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;

class LoginController extends Controller
{
    
    function login(){
        
        $validacion = $this->validate(request(),[
            'email' => 'required|email|string',
            'password' => 'required|string'
        ]);

        if( Auth::attempt($validacion)){
            return redirect()->route('dashboard');
        }
        return back()->withErrors(['email' => 'escribe bien tu correo y contraseña']);
    }

    function showLoginForm(){
        return view('auth.login');
    }

    public function logout(){
        Auth::logout();
         return redirect()->route('adminlogin');
    }


}