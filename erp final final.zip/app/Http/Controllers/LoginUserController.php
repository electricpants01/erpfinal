<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Illuminate\Validation\Rule;
use App\User;
use App\Almacen_Producto;
use DB;
use App\Mail\compraExitosa;
use Mail;
use PDF;

class LoginUserController extends Controller
{
    

    public function login(){
        return view('user.login');
    }

    public function entrar(){
        $validacion = $this->validate(request(),[
            'email' => 'required|email|string',
            'password' => 'required|string'
        ]);

        if( Auth::attempt($validacion)){
            return redirect()->route('super');
        }
        return back()->withErrors(['email' => 'escribe bien tu correo y contraseña']);
    }

    public function logout(){
        Auth::logout();
        return redirect('/');
    }

    public function showRegister(){
        return view('user.register');
    }

    public function register(){
        $credenciales = $this->validate(request(),[
            'name' => 'required|string|max:100',
            'email' => ['email','required','string','max:70',Rule::unique('users')],
            'password' => 'required|required|min:6'
        ]);

        $data = new User();

        $data->name =  request()->input('name');
        $data->email = request()->input('email');
        $password = bcrypt(request()->input('password'));
        $data->password = $password;
        $data->email_verified_at = now();
        if($data->save()){
            return redirect()->route('login');
        }
        return "No se metio a la base de datos, mira el controlador LoginUserController";
    }

    // panel del usuario
    public function super(){
        $user_id = auth()->user()->id;
        $color = DB::select('select color from users where id = ? limit 1',[$user_id]);
        $color = $color[0]->color;
        $letra = DB::select('select letra from users where id = ? limit 1',[$user_id]);
        $letra = $letra[0]->letra;
        $products = Almacen_Producto::where('almacen_id','=',1)->paginate(7);
        return view('user.super')->with(['products' => $products, 'color' => $color,'letra' => $letra]);
    }
	
	public function color($color){
        $user_id = auth()->user()->id;
        DB::update('update users set color = ? where id = ?',[$color,$user_id]);
        return redirect()->route('super');
    }

    public function letra($letra){
        $user_id = auth()->user()->id;
        DB::update('update users set letra = ? where id = ?',[$letra,$user_id]);
        return redirect()->route('super');
    }

    public function carrito(){
        $user_id = auth()->user()->id;
        $color = DB::select('select color from users where id = ? limit 1',[$user_id]);
        $color = $color[0]->color;
        $letra = DB::select('select letra from users where id = ? limit 1',[$user_id]);
        $letra = $letra[0]->letra;
        $products = DB::select('select * from carritos where user_id = ? ',[$user_id]);
        $suma = collect(DB::select('select sum(cantidad * costo_actual) as suma from carritos where user_id = ?',[$user_id]));
        $suma = $suma->toArray();
        $suma = $suma[0];
        if( $suma->suma == null) $suma->suma = 0;
        $pagar = round($suma->suma*1.13,2);
        return view('user.carrito')->with(['products' => $products, 'suma' => $suma,'pagar' => $pagar,'color' => $color,
        'letra' => $letra]);
    }

    public function adicionarCarrito($almacen_id,$producto_id){
        $user_id = Auth()->user()->id;
        $carrito = collect(DB::select('select * from carritos where user_id = ? and producto_id = ? and almacen_id = ? limit 1',[$user_id,$producto_id,$almacen_id]));
        if( count($carrito) > 0){
            // update +1
            $carrito = $carrito->toArray();
            $carrito = $carrito[0];
            $cantidad = $carrito->cantidad +1 ;
            DB::update(' update carritos set cantidad = ? where user_id = ? and producto_id = ? and almacen_id = ? ',
            [$cantidad,$user_id,$producto_id,$almacen_id]);
        }else{
            //nuevo
            $almacen = collect(DB::select('select nombre,costo_actual from 
            almacen_productos where almacen_id = ? and producto_id = ? limit 1',[$almacen_id,$producto_id]));
            $almacen = $almacen->toArray();
            DB::insert(' insert into carritos(nombre,cantidad,costo_actual,almacen_id,user_id,producto_id) values (?,?,?,?,?,?)',
            [$almacen[0]->nombre,1,$almacen[0]->costo_actual,$almacen_id,$user_id,$producto_id]);
        }
        return redirect()->route('super');
    }

    public function compraCarrito(){
        $user_id = Auth()->user()->id;
        $carritos = DB::select('select * from carritos where user_id = ? ',[$user_id]);
        $monto = DB::select('select sum(costo_actual * cantidad) as monto from carritos where user_id = ?',[$user_id]);
        $cant = DB::select('select sum(cantidad) as cant from carritos where user_id = ?',[$user_id]);
        $cant = $cant[0]->cant;
        $monto = $monto[0]->monto;
        $monto_neto = round($monto * 1.13,2);
        DB::insert('insert into facturas(monto,iva,monto_neto,fecha) values (?,?,?,?)',[$monto,0.13,$monto_neto,now()]);
        $max_fact = DB::select('select max(id) as max from facturas');
        $max_fact = $max_fact[0]->max;
        DB::insert('insert into ventas(cantidad,monto,fecha,forma_pago_id,factura_id,user_id) 
        values (?,?,?,?,?,?)',[$cant,$monto_neto,now(),1,$max_fact,$user_id]);
        $max_id_venta = DB::select('select max(id) as max from ventas where user_id = ?',[$user_id]);
        $max_id_venta = $max_id_venta[0]->max;
        foreach($carritos as $carrito){
            DB::insert('insert into detalle_ventas(cantidad,precio,prod_almacen_id,user_id,venta_id)
             values (?,?,?,?,?)',[$carrito->cantidad,$carrito->costo_actual,$carrito->producto_id,
             $user_id,$max_id_venta]);
        }
        DB::update('update almacen_productos,carritos set almacen_productos.cantidad = almacen_productos.cantidad - carritos.cantidad
        where carritos.producto_id = almacen_productos.producto_id and carritos.almacen_id = almacen_productos.almacen_id and carritos.user_id = ?',[$user_id]);
        DB::delete('delete from carritos where user_id = ?',[$user_id]);
        $correo = DB::select('select email from users where id = ?',[$user_id]);
        $correo = $correo[0]->email;
        Mail::to($correo)->send(new compraExitosa($user_id,$max_id_venta));
        return redirect('/');
    }

    public function factura($usuario,$venta){
        $persona = DB::select('select * from users where id = ? limit 1',[$usuario]);
        $sum = DB::select('select sum(precio*cantidad) as sum from detalle_ventas where user_id = ? and venta_id = ?',[$usuario,$venta]);
        $productos = DB::select('select d.cantidad,d.precio,p.nombre from detalle_ventas as d, productos as p 
        where d.prod_almacen_id = p.id and user_id = ? and venta_id = ?',[$usuario,$venta]);
        $pdf = PDF::loadView('factura.factura',['productos' => $productos, 'persona' => $persona,'sum' => $sum]);
        return $pdf->stream();
    }

}
