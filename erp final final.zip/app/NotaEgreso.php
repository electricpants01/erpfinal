<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NotaEgreso extends Model
{
    //
}
