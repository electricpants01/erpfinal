<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Almacen_Producto extends Model
{
    
    protected $table = "almacen_productos";
}
