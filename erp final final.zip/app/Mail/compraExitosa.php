<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class compraExitosa extends Mailable
{
    use Queueable, SerializesModels;

    public $usuario;
    public $venta;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($usuario,$venta)
    {
        $this->usuario = $usuario;
        $this->venta = $venta;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('mail.compraexitosa');
    }
}
